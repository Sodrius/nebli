# Reconstrução da UC08 — Codex administra, Claude executa

Plano v2, 29/09/2026 — consolidado após o primeiro par e a revisão de transferência de contexto. Pedido de Davi: refazer a UC08 do zero, **sem E1**, usando os ajustes de qualidade consolidados; buscar slides no Drive; manter secreções em P2; Claude faz os decks e Codex administra o plano e a revisão. Este documento é a fila vigente desta reconstrução. O lote de 24–25/09 permanece histórico.

## Escopo e significado de começar do zero

- Abrange as aulas de **P1 e P2 da UC08**. Começar pela P1 disponível e calibrar antes de ampliar. Não inclui reconstruir UC03 ou outras UCs.
- Refazer a seleção a partir das fontes atuais, sem importar APKG, plano ou lista de cards antigos como seleção inicial. Um bom candidato antigo pode ser selecionado novamente se passar por nova avaliação; rejeições anteriores continuam valendo.
- “Do zero” não significa escrever tudo do próprio punho: AnKing → externos adequados → autoria excepcional. Cópias NEBLI sobreviventes em outras aulas são verificadas antes de criar uma nova identidade.
- **Sem produzir, revisar, compilar ou publicar E1 neste ciclo.** A E1 antiga não é requisito nem substituto do slide. Na matriz e no fechamento, registrar `E1: não aplicável — pedido de 29/09`. Provas, roteiro, bibliografia, vídeos pertinentes e Step do recorte continuam fontes dos cards. Guia curto pode integrar o relatório, sem virar apostila.
- O reset foi confirmado pelo Claude na execução de FI08 (preflight relatado: 1.173 cards médicos, todos UC03). FI08/BT03 já foram instalados segundo recibos locais; não repetir exclusão/reset. Antes de corrigir, reconciliar a versão viva, preservando o estudo desde a instalação.
- Depois da primeira instalação nova, os ajustes são incrementais nas mesmas identidades, preservando estudo, flags, comentários e suspensões. Não repetir o reset a cada feedback.
- **Referência positiva reafirmada por Davi:** UC03 está mais calibrada; melhorar essa base com pequenos ajustes de qualidade, não inventar novo padrão de seleção para UC08. Ler o retrato de intenção no MEMORY e a referência UC03 em ESTILO. Questionário de 100 itens preparado a pedido dele, ainda sem respostas nesta preparação; não substitui decisões vigentes.

As regras de qualidade continuam nos documentos canônicos do README. As adaptações deste ciclo são escopo, ausência de E1, divisão de responsabilidades e fila. Fora dele permanece a rota normal E1 + cards.

## Responsabilidades e passagem de trabalho

| Responsável | Entrega concreta |
|---|---|
| Codex / GPT | Inventário e fila; briefing da aula; revisão de escopo, seleção, núcleo, tradução e evidências; decisões de correção; atualização dos critérios e da próxima atribuição |
| Claude | Ler fontes atuais; buscar e selecionar candidatos; preparar campos, imagens, tradução e plano por card; revisar a própria produção; corrigir achados; instalar e verificar a versão liberada |
| Davi | Estudar e dar feedback de uso/preferência quando quiser; não auditar todos os cards nem transportar arquivos entre executores |

Troca pelos arquivos locais compartilhados. **Este plano não instala um orquestrador, não inicia o Claude e não garante execução em segundo plano.** Cada executor registra o estado antes de encerrar seu turno. Uma revisão só existe quando o Codex realmente a realizou; Claude não preenche o aceite em nome do revisor.

Uma aula em produção por vez. Claude marca início com data, `run_id` e pasta, completa revisão própria e instala para Davi estudar, conforme F-C43. Codex revisa a versão instalada e devolve achados identificáveis; Claude corrige nas mesmas identidades. Sem revisão Codex efetiva, manter esse estado pendente, sem inventar aprovação. Após cada par, aguardar retorno de Davi antes do seguinte. Não ocupar o lock enquanto espera calibração.

## Inventário conferido em 29/09

Drive docente: [UC08](https://drive.google.com/drive/folders/1iZf8WWtcjNqJtcQLkZcOFQ5qmdrxaWMR). Foram listadas as quatro pastas de componentes e as 14 pastas de aula. “Slide localizado” abaixo significa metadados/listagem, não leitura integral ou conferência visual. O texto de FI08 foi lido pelo conector como teste de acesso; renderização e leitura científica ainda pertencem à execução.

Calendário: [planilha 2026](https://docs.google.com/spreadsheets/d/1T1RZ_vpqtchmdM8U2BXYmlHk7e-Ov-iCGM51PFIEqMU/edit), aba **Mês**, faixas A1:S65 e A66:G78, consultadas em 29/09: P1 em **05/10**, P2 em **30/11**, Turma B. Datas não definem orçamento de cards.

**Conflito identificado:** `Matérias!AB1:AI22` ainda marca FI05/FI06 como P1 e FI08/FI09 como P2. A instrução explícita de Davi, de 24/09 e reafirmada em 29/09, prevalece: **motilidade P1; secreções P2**. Não alteramos a planilha. Não inferir prova apenas da data anterior a 05/10 nem do número no nome do PDF.

### P1 — sete aulas com slides localizados

| ID | Aula / data B | Pasta Drive | Material observado | Estado da reconstrução |
|---|---|---|---|---|
| AN01 | Esôfago, estômago e delgado · 03/08 | [01](https://drive.google.com/drive/folders/1sg4WMtpGzA3LhdZg9M8sXXM0MJkP0llG) | Slides + dois extras; E1 histórica | Fila · piloto anatômico |
| AN02 | Intestino grosso e canal anal · 10/08 | [02](https://drive.google.com/drive/folders/1GATNLKY4BG7oR-iCUBtWpuKXjkRA03Pi) | Slides + dois extras; E1 histórica | Fila |
| BT03 | Estrutura do estômago · 17/08 | [03](https://drive.google.com/drive/folders/1ujdOnueUeBz9uVGzmBRFwCLSX08a_rCG) | Slides; extra na pasta-pai BT; E1 histórica | **Instalado 29/09 (Claude), aguarda revisão Codex** — run `uc08-bt03-20260929a`, **v3 após F-C44: 37 notas/49 cards (19 AnKing, 13 Histology, 2 LLU, 3 autorais; 19 verdes/30 azuis)**; pasta `arquivos-trabalho/deck-aula-uc08-bt03-estrutura-estomago-2026-09-29/`. Pausa do par FI08+BT03 para Davi (F-C43) |
| BT04 | Intestinos · 24/08 | [04](https://drive.google.com/drive/folders/1GSN_lBnaYQh4d1zdMUjQfYnWeXVFs5vd) | Slides; extra na pasta-pai BT; E1 histórica | Fila |
| AN07 | Vascularização das vísceras · 11/09 | [07](https://drive.google.com/drive/folders/1anr09zp44SG100cQsQ-4jMVk6b0rcM2W) | Slides + roteiro + documento de irrigação | Fila |
| FI08 | Motilidade e absorção intestinal I · 14/09 | [08](https://drive.google.com/drive/folders/1sDVPs-kjaAw7VFzYHZkiLfU3Ozm_rXxb) | `Aula-1_MED_2026.pdf`; texto acessado | **Instalado 29/09 (Claude), aguarda revisão Codex** — run `uc08-fi08-20260929a`, **v3 após F-C44: 37 notas/47 cards (29 AnKing, 1 Histology, 7 autorais; 22 verdes/25 azuis)**, PT-BR; pasta `arquivos-trabalho/deck-aula-uc08-fi08-motilidade-i-2026-09-29/` (REVISAO-DE-QUALIDADE.md). Margarida inacessível na sessão; prova não localizada |
| FI09 | Motilidade e absorção intestinal II · 28/09 | [09](https://drive.google.com/drive/folders/1fdb4ci7o_gRURac8DVZFEfc_9FeSKiFk) | `Aula-2_MED_2026.pdf` | Fila |

### P2 — sete aulas, sem misturar com a P1

| ID | Aula / data B na planilha | Pasta Drive | Material observado | Estado da reconstrução |
|---|---|---|---|---|
| FI05 | Esôfago e estômago: secreções e digestão · 24/08 | [05](https://drive.google.com/drive/folders/1dLEyYNKkmu8TMsdKcYrlEboKAOu3yIxp) | `Aula-3_MED_2026.pdf` | Fila P2; conferir extensão real do PDF |
| FI06 | Intestino: secreções e digestão · 31/08 | [06](https://drive.google.com/drive/folders/1qgRJjxVc1bWaCqw4AnsdWK83Wji-sVN_) | Pasta vazia nesta consulta | Aguardar material; procurar também em FI05 |
| BC10 | Fígado e pâncreas — embrio · 19/10 | [10](https://drive.google.com/drive/folders/1TJmcKg6jftonBaEJY7cggHnlQKCYFNG-) | Pasta vazia nesta consulta | Aguardar material |
| AN11 | Fígado, pâncreas e vias biliares · 26/10 | [11](https://drive.google.com/drive/folders/1g2MAvaZlq8SuvTr1DPSDYtxlM5BVz2bp) | Pasta vazia nesta consulta | Aguardar material |
| FI12 | Função hepatobiliar e metabolismo · 09/11 | [12](https://drive.google.com/drive/folders/1WAJMD5RO1AbxclEVOvEGHOAArZd9PkGb) | Pasta vazia nesta consulta | Aguardar material |
| AN13 | Cavidade abdominal e peritônio · 16/11 | [13](https://drive.google.com/drive/folders/1OWV6s-dry8hV4a_HoRYNyKWA0Y9eYh84) | Pasta vazia nesta consulta | Aguardar material |
| AN14 | Inervação do digestório · 23/11 | [14](https://drive.google.com/drive/folders/1YLZmqgZVGJmXNNe58tSt2oLSK0VJhH72) | Pasta vazia nesta consulta | Aguardar material |

Introdução e estudo livre não viram decks artificiais. Títulos amplos não provam conteúdo: “absorção” no nome de FI08/FI09 só recebe cards se o material efetivo sustentar. A classificação P2 de secreções não retira automaticamente de BT03 uma relação célula–função ensinada em histologia, nem de FI09 um efeito motor de hormônio: classificar **alvos**, evitando importar o bloco secretório.

Provas UC08: não localizadas nas buscas desta sessão. Foram listadas as pastas [Provas pessoal](https://drive.google.com/drive/folders/1ZgyavSCg72ZBFpg7dmGr8K-WBYVHPd_C), [Provas compartilhada](https://drive.google.com/drive/folders/1_lkx8ryVqnub5Fs65zeC4Ij3ly21Xo4F) e [provas antigas](https://drive.google.com/drive/folders/1eReSnbZUkmIGxTOuITIvAHctxRapU992), sem ramo UC08; busca por nomes de prova com UC08/UC 8/Digest também vazia. Isso não prova inexistência em todo o Drive. Na execução, ampliar por UC8/Med5043/nomes dos temas e registrar a busca; não pedir download manual. Ausência de prova, isoladamente, não bloqueia curadoria apoiada em slide/roteiro/livro; declarar o limite de calibração por prova.

## Ordem de produção e aprendizagem do pipeline

1. **FI08 — Motilidade I:** primeiro piloto, recorte pequeno; testa seleção causal, concisão, PT-BR, núcleo e controle da expansão clínica.
2. **BT03 — Estrutura do estômago:** testa reconhecimento histológico, contexto/detalhe e fronteira entre estrutura–função e fisiologia secretória.
3. **AN01 — Esôfago, estômago e delgado:** testa acervos visuais, modelos com irmãos, imagens grandes, tradução e um representante verde por estrutura elegível.
4. **AN02 → BT04 → AN07 → FI09**, uma aula por vez, incorporando correções dos pilotos antes de começar a próxima. Verificar compartilhados entre componentes e com UC03.
5. **P2:** FI05 → FI06 → BC10 → AN11 → FI12 → AN13 → AN14 conforme materiais disponíveis. Reconsultar Drive ao retomar; pasta vazia não autoriza inventar aula a partir do livro. Material que abranja FI05/FI06 deve ser segmentado com páginas e objetivos, sem duplicar um deck inteiro.

Essa é a ordem de **produção**, subordinada ao ritmo posterior de Davi (F-C43): parar a cada dois decks para retorno. A sequência de **estudo**, metadados e tópicos segue o professor. Nenhuma implementação de ordenação/painel é presumida. O primeiro par recebeu crítica de cobertura/forma (F-C44) e correções v3 relatadas pelo Claude. Incorporar também F-20260929-CLAUDE-01: Davi devolveu ao executor o julgamento de cobertura e número de verdes; não exigir dele esse aceite técnico. Conferir/corrigir o par antes de seguir a fila conforme o pedido ativo; pedido de preparar contexto/questionário não inicia outra aula.

## Ciclo por aula

| Etapa | Executor / artefato | Condição de passagem |
|---|---|---|
| 1. Briefing | Codex: ID, prova, fontes, fronteiras, risco de repetição e versão dos critérios | Aula atribuída na fila; outras UCs preservadas |
| 2. Fontes e mapa | Claude: `fontes.json`, `matriz-objetivos.tsv` | Slide/roteiro lidos; provas buscadas no início; livro no trecho pertinente; fontes ausentes com impacto |
| 3. Candidatos e proposta | Claude: `plan.json`, buscas/recusas e `translation-plan.json` | Alvo, origem/cloze, cobertura, versão PT e cor específica por card; sem cota de verdes/cards/autorais |
| 4. Revisão própria | Claude: `REVISAO-DE-QUALIDADE.md`, incluindo aplicação concreta do padrão de Davi | Conteúdo, versos, seleção e evidências conferidos; limites declarados; problemas conhecidos corrigidos |
| 5. Instalação | Claude: snapshot, `journal.jsonl`, `receipt.json`, `verification.json` | Revisão própria concluída; estado vivo reconciliado; lock via `nebli.decks.escrita()`; dry-run e modelos validados |
| 6. Revisão Codex, estudo e ajuste | Codex: `REVISAO-CODEX.md`; Claude: correções e entrega breve | Revisar versão instalada; achados/feedback corrigidos nas mesmas notas; pausa para Davi a cada par antes do próximo briefing |

**Ritmo definido por Davi em 29/09, depois deste plano (F-C43):** "quero que você rode o plano, parando a cada dois decks para eu ver, daí faço ajustes e vamos melhorando". Claude instala cada aula após a revisão própria completa, para Davi ver no Anki. A revisão do Codex incide sobre a versão instalada, e as correções entram nas mesmas notas. Após cada par de decks, Claude para e aguarda o retorno de Davi.

Artefatos ficam juntos em `arquivos-trabalho/deck-aula-uc08-<id>-<slug>-<data>/`; reexecuções usam versão/run_id sem sobrescrever evidência anterior. Campos e arquivos completos de cards permanecem privados conforme `.gitignore`. Os nomes acima são contrato de trabalho assistido, não promessa de um gerador que já os produza automaticamente.

O plano de cada card registra os campos exigidos em BANDEIRAS-E-PROGRESSAO, mais origem real, cloze/template selecionado, ordem docente, decisão de inclusão/exclusão e referências da tradução. Contar cards, não somente notas. Fonte externa original, base curada e tradução são versões distintas: limpeza/correção antes da tradução tem decisão própria; tradução preserva integralmente a base aprovada e arquiva o inglês.

O Codex verifica a seleção inteira por alvo/cloze e as evidências de cobertura; inspeciona todos os autorais/adaptações e alvos visuais pertinentes, lendo frente e verso. Exemplos na conversa são ilustração da entrega, não substituto da revisão. Não liberar toda a aula com base apenas em amostra ou script. Achado recebe `id`, card/objetivo, problema, ação, evidência requerida e estado. Liberação identifica run_id, versão/hash de seleção/campos/templates e limitações; alteração posterior invalida a parte afetada.

## O que significa qualidade suficiente

Aplicar o padrão de Davi em README § O que Davi quer em toda sessão, com evidência concreta na revisão. CONTRATO, ESTILO-ANKING, TRADUCAO e BANDEIRAS detalham esse padrão; não são convite a redesenhá-lo. Nesta reconstrução, acompanhar especialmente:

| Dimensão | Evidência necessária | Sinal de regressão |
|---|---|---|
| Escopo e cobertura | Cada alvo ligado ao material atual; teoria/prática separadas; exclusões justificadas | Aula de motilidade vira curso de doenças; P2 importada por palavra compartilhada |
| Seleção e autoria | Busca AnKing ampla, segunda rota e externos por lacuna importante | “Não achei” genérico; recriar lista antiga de autorais |
| Recuperação | Frente focal, autocontida, sem pistas; verso curto explica quando útil | Frase curta que exige várias respostas independentes; caso longo sem ganho |
| Núcleo | Uso futuro e necessidade daquela recuperação; lacunas e excesso de verdes conferidos | Tudo verde por ser fisiologia/anatomia; perseguir média 40 |
| Redundância | Comparação alvo + resposta + habilidade na UC e compartilhados | Texto/idioma diferente contado como ganho; dois verdes da mesma estrutura anatômica |
| Visual e PT-BR | Imagens inspecionadas, máscaras certas, legibilidade e renderização; semântica/HTML/clozes preservados | Imagem presente mas ilegível; legenda entrega resposta; irmão indevido regenerado |
| Uso e integridade | Conjunto exato de IDs estudáveis, uma identidade, originais preservados | Tag de nota tomada como seleção de cards; sync tomado como chegada confirmada ao tablet |

Sem nota numérica arbitrária de “qualidade extrema”. Erro científico, recorte errado, resposta vazada, visual errado, duplicação indevida e perda de identidade impedem liberar os cards afetados. Falta de fonte indispensável ou cobertura essencial mantém a aula parcial, sem rotular pronta. Revisão técnica e revisão de conteúdo têm estados separados.

Sem teto de tamanho, porcentagem desejada de autorais ou meta de verdes. Cerca de 400 respostas/dia é observação de carga, não orçamento de seleção. Alto volume/autoria exige revisar busca, alvos e repetição; não cortar fundamentos para caber. Azul é card bom de menor custo de esquecimento; não destino de conteúdo ruim.

## Reset, instalação e compartilhados

Antes da primeira escrita, executar preflight vivo e registrar perfil, raízes, acervos, modelos, comentários, flags e sobreviventes associados à UC08. Se o deck antigo ainda estiver presente, concluir preparação sem misturar versões e registrar `aguarda reset informado por Davi`; não excluir em nome dele. Se não houver acesso, registrar `estado do reset não verificado`, não pedir que ele faça uma bateria de checagens manuais.

Após o reset, reconciliar por origem + recuperação/cloze, não por IDs de notas apagadas. Referências históricas a IDs deixam de comprovar presença. Preservar cards vivos de UC03/outras aulas e seu histórico; associar alvos pertinentes à UC08 sem duplicar ou movê-los. Se a mesma nota contiver irmãos fora do recorte, testar a seleção exata e a geração antes de aplicar. Não restaurar histórico de cópias excluídas a partir de backup nem ressuscitar conteúdo rejeitado para fechar pendência antiga.

Instalar cada aula liberada e sincronizar no mesmo dia, com backup, lock, readback e preservação de opções. Manter preset único e os novos cards ativos; suspensão é decisão de Davi. Compartilhados exigem seleção por IDs validada; consulta de navegador não deve ser anunciada como botão de estudo pronto. APKG local da UC viva, comprimido e sem flags no arquivo; upload continua pausado. Não exportar pacotes antigos como se fossem a reconstrução.

Histórico da preparação Codex: preflight bloqueado pelo sandbox (`Operation not permitted`), tentativa de liberação interrompida e nenhuma escrita naquela preparação. Recibo: `arquivos-trabalho/reconstrucao-uc08-2026-09-29/preflight-planejamento.json`. Isso não descreve o estado posterior: Claude relatou reset e instalação de FI08/BT03 nas respectivas corridas. A revisão atual dos documentos não refez leitura viva nem escreveu no Anki.

## Feedback e evolução sem perder o que funcionou

Para cada feedback: preservar pedido/exemplo → determinar se afeta card, aula ou regra geral → corrigir os alvos afetados → registrar antes/depois e verificação → conferir a mesma regressão nos decks novos já entregues → incorporar na próxima aula. **Todo feedback**, local/geral/positivo, recebido por qualquer executor fica registrado na mesma sessão em FEEDBACKS, conforme seu protocolo; atualizar regra pertinente e síntese do MEMORY, enquanto a fila guarda estado e links. Reconciliar entradas novas da outra IA antes de fechar.

Cada execução anota a versão dos critérios. Uma mudança de pipeline declara o problema concreto, o ajuste e como foi verificado. Alterar código apenas quando uma falha observada exigir; então testar o comportamento afetado. Não construir agora painel, tutor, alternância EN/PT ou automação universal como pré-requisito para bons decks.

No acompanhamento do conjunto: verdes únicos e compartilhados, motivos de exclusão, lacunas, autoria necessária, retrabalho por tipo de erro e feedback real de estudo. Revisões, lapsos ou sanguessugas só entram se houver dados vivos suficientes; contagem/velocidade isoladas não demonstram aprendizagem. Davi recebe onde estudar, cobertura, núcleo, poucos exemplos e pendências materiais.

## Referência do primeiro briefing — FI08 já executada

**FI08, P1 — Motilidade I.** Fonte inicial: [Aula-1_MED_2026.pdf](https://drive.google.com/file/d/1kUUqmssC4UrxI1EzmbjeqNu7wyyMkR9R/view). Livro do curso: Margarida de Mello Aires, localizar capítulo pertinente na pasta Livros conforme README; presença não prova leitura.

O texto consultado mostra inervação intrínseca/extrínseca, plexos, reflexos curtos/longos, contração/relaxamento, esfíncteres e um exemplo de Chagas. São pistas para o mapa, **não seleção científica pronta**. Reabrir PDF e figuras; verificar mecanismos e afirmações esquemáticas na bibliografia antes de formular cards. Menção ao plexo submucoso não abre o bloco inteiro de secreções. O título da pasta não autoriza acrescentar absorção ausente do PDF. Chagas ilustra o mecanismo ensinado, sem importar diagnóstico/tratamento.

Esse briefing delimitou a primeira execução; não manda recriá-la. Confrontar a versão atual FI08/BT03 com F-C44, F-20260929-CLAUDE-01 e o padrão em README/MEMORY, revisar a versão viva, corrigir incrementalmente e registrar o resultado. Não gerar E1 nem reaplicar script antigo. Seguir o ritmo por pares e o pedido ativo; o retorno já registrado de Davi não deve virar uma nova pergunta sobre quantidades.

**Estado conhecido nesta consolidação:** FI08/BT03 receberam v3/v3c segundo Claude; tabela já registra 47/49 cards e a consulta pontual aos nomes no Anki observou essas contagens. Não é auditoria semântica nem aprovação da tradução. Feedback posterior do Claude está no registro comum. Próxima execução deve reconciliar versões/evidências e incorporar o retorno recebido, sem pedir ao aluno que julgue cobertura/verde. Nenhum novo deck ou alteração Anki foi executado pelo Codex nesta consolidação de memória/questionário.
