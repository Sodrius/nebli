# Bandeiras e progressão médica
Política de Davi consolidada em 25/09 e refinada em 28/09/2026 (F-C28). Classificar a **recuperação daquele card**, não o nome amplo do assunto. Cor recomenda retenção, não frequência garantida de prova.

| Bandeira | Significado e ação |
|---|---|
| Verde, flag 3 | Recomendo manter esse card a longo prazo. |
| Azul, flag 4 | Vale aprender agora; esquecer depois terá menor custo futuro. Continua ativo; Davi decide se suspende. |
| Branca/sem bandeira, flag 0 | Realmente não consegui avaliar. Registrar qual informação falta; não usar como default por preguiça ou ausência de tag HY. |
| Vermelha, flag 1 | Pedido de melhorar/rever/remover; tratar antes da recomendação de retenção. |
| Laranja, flag 2 | Comentário pendente; limpar apenas após resolver e conferir. |
| Rosa, flag 5; outras | Legado ou marca pessoal. Não atribuir em novas criações nem converter toda a coleção sem pedido. |

Bandeira única não comporta simultaneamente feedback e retenção. Preservar marca pessoal; guardar recomendação no plano enquanto houver vermelho/laranja ou conflito. Se uma flag mudou desde o snapshot, não sobrescrever. Tag HY original é evidência auxiliar, não requisito nem ordem de pintar verde.

**Transição:** cores antigas ainda podem refletir regras antigas. Até revisão identificada no recibo, um branco antigo pode estar simplesmente não avaliado e um verde antigo pode ser apenas HY literal. Não contar toda a coleção como já classificada pela política nova; não migrar em massa para disfarçar essa diferença.

## Julgamento, antes de escolher a cor
Primeiro: o card é correto, focal, compreensível, pertinente e não duplicado? Se não, corrigir/retirar; **azul não é lixeira de cards ruins**.
Depois formular, fora do card: “Quero que Davi ainda saiba X quando chegar a Y, porque isso permite Z.” X precisa ser o alvo exato da pergunta; “base médica”, “anatomia importante” ou “mecanismo útil” não bastam como motivo repetido para um deck inteiro.
A cor é decidida **no plano, junto com a seleção** (25/09), com esse motivo curto gravado por card; não é passada posterior nem default. Sem bandeira só com a dúvida escrita no plano.

**Verde** quando lembrar ativamente aquele alvo tem utilidade recorrente e concreta: mecanismo causal transferível entre sistemas; estrutura/relação essencial para reconhecer ou explicar doença; distinção central; base de raciocínio, interpretação ou segurança clínica que custaria reaprender. Não exige aplicação imediata à beira do leito nem tag HY. Fonte externa/autoral elegível recebe o mesmo julgamento.

**Azul** quando o alvo é válido nesta aula, mas o ganho de revisão continuada é comparativamente menor: nomenclatura secundária, detalhe local, limiar contextual ou pormenor cuja perda permite reconstruir o principal. Não rebaixar toda anatomia/histologia, nem usar “é só nome” para sinais/estruturas fundamentais.

**Branco** apenas com dúvida específica: fonte conflitante, objetivo incerto ou valor futuro que a evidência ainda não esclarece. Se a dúvida é correção científica que compromete estudar, tratar como pendência de qualidade, não entregar como fato seguro branco.

Duas perguntas inversas/visuais podem ser ambas verdes se testarem habilidades distintas, **com a exceção de anatomia solicitada em 28/09**: podem existir várias práticas da mesma estrutura, mas somente um representante verde por estrutura. Escolher o melhor card correto, preferindo AnKing, depois outros acervos anatômicos, e AnatoKing por último. Os demais ficam disponíveis em azul; erro visual continua sendo pendência de qualidade. Registrar o grupo e o ID do representante, inclusive quando as cópias estão em aulas distintas. Um card compartilhado tem uma recomendação global para Davi, não uma cor por aula.

## Núcleo e referências de calibração

**Respostas posteriores de Davi em 28/09 prevalecem (F-C35):** “40 é só um chute”, “o que importa é marcar de verde o que importa”. A referência de aproximadamente 40 serve para pensar e acompanhar o conjunto; não determina cor, tamanho ou aprovação do deck. Davi prefere observar uso/carga antes de reclassificar por causa da média. Analisar blocos de várias aulas/matérias principalmente; cortes por UC/semestre também ajudam, sem janela rígida. Exemplos de 5 e 80 mostram variação possível, não limites.

**Compartilhados:** um card na coleção, uma revisão, uma recomendação global. Aparecer em duas aulas não lhe dá preferência nem o torna automaticamente verde. Exibir associações quando necessário para cobertura; contar união de IDs para carga real, sem multiplicar prioridade ou trabalho de revisão.

Aulas com muitos fundamentos importantes terão núcleo grande; outras podem ter muito pouco a manter. Aula longa ou muitos slides não provam importância longitudinal; aula curta pode conter um fundamento decisivo. Zero verdes novos também pode ser correto se o núcleo já estiver coberto por cards compartilhados — registrar essa cobertura, não criar outra revisão. Esclarecimento clicável final: **cerca de 400 respostas totais/dia; 40 apenas referência de calibração, sem meta separada de novos**.

Separar três decisões, nesta ordem:

1. **Merece estar disponível?** É correto, compreensível, pertence à aula e acrescenta aprendizagem/prática. “Melhor ter do que faltar” vale aqui; não inclui erro, clínica lateral ou repetição sem ganho fora da exceção anatômica.
2. **Precisa ser recuperado sem consulta no futuro?** Identificar o que fica prejudicado se esse alvo for esquecido: explicar uma relação central, reconhecer estrutura/sinal, distinguir situações ou compreender aulas seguintes. “Foi cobrado uma vez” ou “consta no livro” não responde isso.
3. **Este card é necessário para esse núcleo?** Comparar com os outros verdes, versos e relações que permitem reconstruir a resposta. Se basta outro card melhor, este não ganha verde por ser uma segunda formulação correta. Se a recuperação acrescenta algo central, não cortá-la só para deixar o núcleo pequeno.

Preferência explicitada em Q4B: alvo facilmente dedutível em segundos a partir de fundamento já retido tende a azul ou ao verso. Conferir se a reconstrução é realmente simples e suficiente; não apagar alvos essenciais usando “dá para deduzir” genericamente.

Fazer as duas conferências: **falta algum alvo duradouro essencial?** e **há algum verde cujo motivo é genérico, redundante ou apenas importância local?** Cobertura da aula e cobertura do núcleo são verificações distintas. Azul continua válido e ativo; Davi decide a manutenção final. Cor recomenda, não suspende.

### Como usar as referências de importância

| Referência | O que sustenta | O que não autoriza |
|---|---|---|
| Aula e prova local | Pertinência, objetivo e profundidade estudada | Tratar toda cobrança local como compromisso vitalício |
| Steps e provas de residência pertinentes | Evidência adicional de aplicação recorrente do mesmo alvo | Importar assuntos fora da aula ou declarar frequência sem questões/fontes consultadas |
| Formação médica geral e bibliografia | Fundamentos que organizam raciocínio e aprendizagem posterior | Justificativa vaga de que “tudo pode ser útil” |
| Fisiologia — importância especial para Davi | Relações causais, regulação, resposta a perturbações e integração entre sistemas | Promover cada número, etapa ou exceção por pertencer à disciplina |
| Anatomia — importância especial para Davi | Reconhecimento, localização e relações espaciais estruturantes | Promover toda legenda/variante; ignorar a regra de um representante por estrutura |

HY pertinente é evidência favorável forte; não exigir tag para reconhecer importância nem transferir o HY da nota a todos os clozes. A relação direta com doença pode justificar verde quando o alvo é de fato fundamental e compreensível. **Godet**, exemplo dado por Davi, serve para reconhecer e entender um sinal da própria aula de edema; não autoriza abrir um deck sobre todas as doenças que causam edema. Nenhuma fonte isolada decide todas as cores.

**Story teller (F-C36):** card que ensina e relembra uma relação, frequentemente de forma atômica no AnKing; não exige caso ou narrativa. Pode ensinar clínica que Davi já consiga captar e que seja DIRETAMENTE ligada à aula. Sem cota de story tellers. Bom card básico permanece; aplicação vai preferencialmente ao verso, salvo ganho excepcional de recuperação própria (Q11C). Avaliar o alvo para verde; evitar introduzir complexidade clínica que apenas amplia o conjunto azul. Critérios de conteúdo no CONTRATO, estilo em ESTILO-ANKING.

Para anatomia, primeiro decidir se a estrutura pertence ao núcleo; só então escolher seu único representante verde. Não forçar um verde para toda estrutura cadastrada. Preferência de acervo não dispensa qualidade, imagem correta e legibilidade. Não agrupar estruturas diferentes porque compartilham uma imagem ou porque seus nomes aparecem no mesmo enunciado.

### Evidência mínima no plano, por card/cloze

Registrar `alvo`, `evidencia_na_aula`, `uso_futuro_concreto`, `por_que_recuperacao_ativa`, `comparacao_com_cobertura_existente`, `recomendacao`, `motivo` e `incerteza` (vazia quando resolvida). Quando pertinente: referência Step/residência realmente consultada e grupo anatômico/ID representante. Fonte ausente é declarada; não inventar capítulo ou recorrência para preencher o campo. Esses são requisitos do plano assistido, **não campos já implementados no banco**.

Exemplos de julgamento, não reclassificação aplicada:

- Godet: verde pelo reconhecimento do achado e compreensão do que a depressão representa; não pelo simples uso de um epônimo.
- Um mecanismo fisiológico central: verde se sua recuperação permite prever uma consequência relevante e não está coberta por outro card. Uma etapa acessória reconstruível pode ser azul.
- Segunda imagem da mesma estrutura: azul de prática quando correta e útil; o representante concentra a manutenção. Imagem com alvo errado precisa de correção, qualquer que seja a importância da estrutura.
- Nome de método/valor isolado: avaliar o papel concreto. Não pintar azul por ser um número nem verde por ter aparecido numa prova; uma distinção operacional central pode merecer retenção.

Relatar alvos do núcleo e cards verdes únicos, azuis, incertos, feedbacks, compartilhados e suspensos. Distinguir **núcleo presente na aula** de **novas revisões acrescentadas**. Somar por aula duplica compartilhados; carga longitudinal usa união de card IDs. A contagem descreve a seleção, não a aprova.

**Cerca de 400 respostas totais/dia**, mais cramming à parte, é referência flexível (Q25C e esclarecimento posterior); tempo e qualidade da sessão pesam mais. Não equivale a novos/dia nem limita o tamanho do deck (F-C18). Carga exige dados reais de revisão. Não tornar todo o deck verde para garantir cobertura nem esvaziar o núcleo para cumprir o ritmo.

## Estudo inicial: Step 1 e os próximos anos
Fontes oficiais consultadas em 25/09/2026. Não é revisão exaustiva de toda a medicina nem previsão do edital futuro.

O Step 1 privilegia aplicação de fundamentos (60–70% das tarefas); Patologia (45–55%) e Fisiologia (30–40%) são disciplinas muito representadas, com categorias sobrepostas. Anatomia/Embriologia, Histologia, Microbiologia, Imunologia e outras bases também compõem a prova. Isso favorece preservar mecanismos e reconhecimento, não apenas decorar rótulos. O outline não é currículo completo nem promete que cada tópico cairá. Fonte: [USMLE — conteúdo e especificações](https://www.usmle.org/exam-resources/step-1-materials/step-1-content-outline-and-specifications).

O projeto pedagógico FMUSP publicado em abril/2024 descreve quatro anos básico-clínicos, seguidos de dois de internato. Sua matriz prevê, no segundo ano, sistemas respiratório, urinário, endócrino, locomotor, reprodutor e cardiovascular; depois aprofunda clínica, nefrologia, infectologia, digestório, hematologia/imunologia e prática ambulatorial. No quarto ano integra situações clínicas/cirúrgicas, pediátricas e gineco-obstétricas; a ordem de semestres varia por turma. Fonte: [FMUSP — projeto pedagógico, pp. 47–52](https://fm.usp.br/graduacao/conteudo/projeto_pedagogico_curso_de_medicina_abril_2024-1.pdf).
**Limite:** matriz institucional de 2024, não confirmação do cronograma individual 2027–2029. Datas/aulas efetivas dependem da planilha e programas vigentes.

### Aplicação à curadoria — inferências, não classificação oficial de cards
| Base dentro da aula atual | Uso futuro que orienta o julgamento | O que não importar agora |
|---|---|---|
| Forças capilares, albumina, linfa, permeabilidade | Explicar edema em contextos cardiovasculares, renais e inflamatórios | Todo diagnóstico diferencial/tratamento de edema |
| Reconhecimento imune, complemento, inflamação | Entender infecção, lesão tecidual e mecanismos imunes | Painel extenso de imunodeficiências/exames laterais |
| Relação vascular e reconhecimento anatômico | Localizar territórios/lesões e compreender circulação | Todas as variantes raras e técnicas cirúrgicas |
| Estrutura histológica ligada à função | Reconhecer normalidade e explicar alteração funcional | Listas de marcadores usados só como ilustração |
| Regulação metabólica | Integrar estado alimentado/jejum e doença do metabolismo | Tratamento completo de doenças apenas citadas |

Usos futuros ajudam a **selecionar e colorir dentro do recorte**, não autorizam antecipar outras aulas. Confirmar fonte médica específica quando houver dúvida factual; tabela não substitui bibliografia.

## Calibração incremental
Primeiro uma amostra pequena com justificativas por card; depois ampliar por aula/lote aprovado. Não recolorir a coleção toda nesta mudança. Guardar antes/depois e estado do perfil. A amostra de Edema desta sessão e o teste de compartilhados estão no relatório em HISTORICO/MEMORY.
