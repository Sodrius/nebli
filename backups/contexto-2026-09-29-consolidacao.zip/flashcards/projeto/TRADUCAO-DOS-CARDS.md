# Cards em português — arquitetura de tradução

Pedido de Davi em 28/09/2026, F-C29. **Estado em 29/09: contrato de tradução; Claude relata PT-BR instalado em FI08/BT03, ainda sem certificação integral pelo Codex.** Os registros locais mostram curadoria e tradução combinadas e revisão visual declarada no relatório, mas ainda pendente nos registros por nota. A direção é português brasileiro de qualidade; uma aplicação assistida não valida um tradutor universal. A preferência anterior por frente em inglês com apoio PT não autoriza traduzir a coleção inteira nem modificar originais. **Q22: tradução nas próximas aulas**, sem migração geral. Critérios de seleção e retenção continuam em README, CONTRATO e BANDEIRAS-E-PROGRESSAO.

## Experiência pretendida

Frente e resposta naturais em português; uma pergunta focal, contexto suficiente e explicação curta que ajude a entender e lembrar. Extras pertinentes podem ficar recolhidos. Preservar termos ingleses úteis ao Step como equivalentes discretos no verso, sem criar uma segunda fila de revisão nem sobrecarregar todas as respostas com duas línguas. Siglas, nomes científicos, símbolos e nomenclaturas consagradas não recebem tradução mecânica.

Traduzir **a recuperação**, não palavras isoladas. A pergunta em português deve cobrar a mesma relação e aceitar a mesma resposta conceitual. Não aproveitar a tradução para alongar o card, acrescentar clínica, criar clozes, eliminar irmãos ou reclassificar sua importância. Correção científica necessária é uma alteração separada, com fonte e nova revisão do conteúdo. Tradução não torna um card ruim adequado.

**Preservação integral, explicitada por Davi em 28/09 (F-C33):** manter todo o conteúdo, formatação, negrito, itálico, sublinhado, cores, listas, tabelas, blocos recolhíveis, mídia, links, tags de organização, campos, clozes e identidade. Traduzir texto não autoriza limpar, resumir, remover extras/mnemônicos ou padronizar visual. Conservar marcações HTML e seus atributos; o destaque acompanha o trecho semanticamente correspondente em português, mesmo quando a ordem natural das palavras muda. Tags do Anki e identificadores não são traduzidos, renomeados nem removidos. Melhoria editorial/visual é operação separada, registrada como tal.

A implementação deve editar trechos textuais sem reconstruir o HTML como texto simples e comparar estrutura/atributos e conjunto de tags antes/depois, além de inspecionar o resultado. A comparação local `amostra.html` da rodada anterior retira marcação somente para exibição editorial: **não é implementação da tradução nem prova de preservação visual**. A próxima amostra de aceite precisa usar o template e a formatação reais.

**Aprendizado dos pilotos de 29/09:** uma lista `change_kind: [translation, curation, didactic_edit]` com original EN e resultado PT não basta para demonstrar preservação da tradução. Se houver outras edições, guardar também a **base depois da curadoria e antes da tradução**, com os motivos das alterações; comparar essa base com PT campo a campo e cloze a cloze. Mudança de negrito, largura da imagem ou exclusão de irmão não pode desaparecer sob uma declaração genérica de tradução fiel. Atualizar a revisão por nota para a mesma versão realmente renderizada/instalada; `reviewed` junto de `visual: pendente` não é aprovação completa. Conferência textual local e relatório do executor não substituem readback/renderização próprios quando se declara revisão independente.

## Decisão técnica: uma identidade, texto revisado e original recuperável

Primeira versão proposta: traduzir os campos apresentados da **cópia NEBLI existente**, depois de revisão, mantendo nota, cards, clozes/templates, associações e agendamento. Guardar antes/depois completos num registro local privado versionado por execução. Não criar deck PT paralelo, converter o tipo de nota ou duplicar o campo gerador de cloze para alternar idiomas no MVP.

No Anki, as notas geram cards; números de cloze determinam recuperações, e condições do template afetam geração. Preservar somente a contagem total não prova que os mesmos cards continuam existindo. É necessário comparar IDs, ordinais e renderização. Referências consultadas em 28/09: [cloze no manual](https://docs.ankiweb.net/editing.html#cloze-deletion) e [geração de cards](https://docs.ankiweb.net/templates/generation.html).

| Camada | Responsabilidade |
|---|---|
| Origem externa | Campos/modelos originais intactos; namespace e identidade de origem registrados |
| Base NEBLI antes da tradução | Texto efetivamente adotado, incluindo correções anteriores; não regressar ao original externo defeituoso |
| Proposta PT | Texto/HTML traduzido, glossário utilizado, decisões terminológicas e revisão por alvo |
| Registro da execução | Hashes, antes/depois, IDs/clozes/templates, seleção de irmãos, estado da revisão e recibo |
| Anki | Só a versão aprovada; histórico e intervenções pessoais preservados |

Não há hoje tabela de tradução no `nebli/registry.py`: a implementação existente registra aula, fonte, publicação e execução. Inicialmente, usar `translation-plan.json` na mesma pasta da corrida, referenciado pelo `plan.json`. Uma futura migração do registro deve importar esses recibos, não virar fonte concorrente de verdade. A arquitetura não depende de API paga adicional: o executor faz tradução/revisão; scripts locais validam estrutura e aplicam mudanças.

Inglês de apoio, quando necessário, fica no verso como texto comum revisado. **Q21C: guardar o inglês, sem exibir o original completo agora.** Davi quer futuramente um add-on com versões PT/EN vinculadas para poder passar a estudar em inglês, mantendo uma identidade e o histórico. Preparar a correspondência entre versão, nota, card e cloze no registro; não implementar agora campos geradores ou JavaScript por idioma. Original preservado no registro permite conferência/reversão pelo executor; não prometer acesso por botão no tablet antes de implementá-lo e testá-lo.

## Fluxo por lote pequeno

1. **Fixar a versão a traduzir.** Ler nota viva, cards/ordinais, templates, comentários e mídia. Confirmar cópia NEBLI; incorporar correções já aplicadas. Mapear todos os irmãos, inclusive os fora da aula corrente: a edição do campo é por nota.
2. **Mapear a recuperação de cada card.** Pergunta implícita, resposta, condições, contraste e pistas disponíveis antes de responder. Entender a imagem e os campos do modelo antes de modificar texto.
3. **Consultar terminologia.** Bibliografia da matéria e termos usados na aula orientam o português. Glossário pequeno por conceito, com termo PT, equivalente EN, sinônimos aceitos, contexto, fonte consultada e ambiguidade. Duas nomenclaturas válidas podem coexistir com nota breve, conforme Q20; não declarar uma inválida por tradução literal.
4. **Redigir em PT-BR.** Priorizar leitura fluida e precisão. Reordenar a frase se necessário; conservar causalidade, condições, intensidade, lateralidade e a resposta cobrada. Número de palavras é diagnóstico, não limite: português pode ocupar mais espaço.
5. **Revisar significado e didática separadamente da primeira redação.** Comparar proposições e respostas diretamente com a base; conferir fonte médica quando houver ambiguidade. Retrotradução pode denunciar problemas, mas não certifica qualidade. Uma segunda leitura pelo mesmo executor não é revisão independente por outro especialista.
6. **Validar estrutura e visualizar.** Comparar conjunto de cards, fronteiras dos clozes, recursos, pergunta/resposta de cada irmão afetado, larguras desktop/mobile e temas claro/escuro. Modelos não suportados ficam pendentes; não tentar consertá-los com substituição textual geral.
7. **Aplicar somente o lote aprovado pelo executor.** Precondições, backup, `nebli.decks.escrita()`, escrita suportada pelo Anki e leitura de conferência. A revisão de qualidade é responsabilidade do executor; não exigir que Davi confira cada tradução.
8. **Verificar a mesma identidade após aplicação.** Mesmo conjunto de IDs/ordinais, originais intactos, nenhuma alteração atribuível à tradução em flags/suspensões/agendamento. Se Davi revisou durante o processo, preservar essas revisões; não restaurar snapshot de agendamento. Sync aceito é diferente de teste no Android.

Um card ainda sem tradução segura permanece na versão anterior utilizável, com pendência registrada no relatório. Se houver erro científico que inviabilize estudar, seguir o fluxo de correção, sem escondê-lo sob “tradução pendente”. Lotes mistos são estado transitório declarado, não entrega integralmente traduzida.

## O que a revisão precisa detectar

| Risco | Verificação concreta |
|---|---|
| Negação, direção ou causalidade alterada | Conferir sujeito, ação, objeto, condição e qualificadores; “pode” não vira “sempre” |
| Falso cognato/termo regional | Usar contexto médico e bibliografia; não traduzir `tenderness` como “ternura” |
| Número, unidade ou notação | Preservar valor e unidade; `1,000` em inglês pode virar `1.000` em PT, não `1,000` com sentido decimal; não converter unidades por conta própria |
| Pista gramatical nova | Ler a frente oculta: artigo, gênero, número ou concordância podem revelar a resposta; reescrever o contexto sem alterar o alvo |
| Resposta entregue | Examinar hints, sinônimos, títulos, legendas, imagem e campos herdados; equivalente inglês da resposta não aparece na frente |
| Cloze mudou de pergunta | Preservar números, agrupamentos, hints e semântica de cada ocultação; `c2` não vira `c1` para “arrumar a sequência” |
| Resposta demasiadamente ampla | Não expandir o trecho oculto com uma explicação inteira; manter explicação no verso |
| Tradução local inconsistente | Mesmo conceito usa termo consistente; homônimos e contextos diferentes não são substituídos em massa |
| Mnemônico deixou de funcionar | Preservar bons mnemônicos existentes; não inventar substitutos com IA. Explicação é alteração editorial identificada. Tradução sozinha não autoriza retirar conteúdo |
| Texto e imagem divergem | Traduzir legenda textual sem mudar a estrutura apontada; conferir nome, seta, máscara, orientação e lateralidade |

### Adaptadores por modelo

- **AnKing/cloze textual:** mapear Text, Extra e demais campos exibidos; preservar HTML, LaTeX, mídia, controles One-by-One e campos de identidade. Nomes dos campos, tags, URLs e nomes de arquivos não são linguagem a traduzir.
- **Básico/pergunta-resposta:** traduzir os campos apresentados e testar as condições que geram cada template, inclusive inversos existentes. Não criar um inverso novo.
- **Dope, AnatoKing e modelos visuais:** mapear campos de resposta e texto fixo nos templates. Um modelo pode ter vários pares pergunta/resposta; não tratar a nota inteira como um único card. Mudança num template NEBLI afeta todas as notas desse modelo e exige revisar esse alcance antes de aplicar.
- **Oclusão e rótulos embutidos:** não traduzir coordenadas, IDs de máscaras, SVG técnico ou binários como prosa. **Q17C: rótulos embutidos permanecem em inglês; traduzir o texto do card.** Manter imagem original; equivalente PT no verso somente se útil e sem dar pista. Edição de rótulos não integra este escopo. Não declarar a imagem traduzida quando só a legenda mudou.

Para o piloto, suportar primeiro cloze simples e uma família visual mapeada. Aninhamento, sintaxe de múltiplos índices e modelos desconhecidos exigem suporte explícito; uma expressão regular simples não valida o universo de clozes.

## Contrato mínimo de dados e atualização

```text
run_id, lesson_ids, note_id, card_ids, source_identity, model_name
source_original_ref, nebli_base_fields, base_fields_hash, template_hash
language_versions: en_base_ref, pt_proposal_ref, shared_card_map_ref
card_map: card_id → ordinal/cloze → alvo → resposta conceitual
proposed_fields, glossary_version, terminology_decisions
change_kind: translation | scientific_correction | didactic_edit
review: semantic, language, structure, visual, limitations
state: draft → reviewed → ready_to_apply → applied → verified
       conflict | partial | failed (com motivo)
applied_fields_hash, before_ref, receipt_ref
```

Cada revisão se refere aos hashes concretos, não apenas ao `note_id`. Uma alteração de fonte, texto ou template invalida a parte afetada da revisão. Não usar `translation` como categoria para uma correção científica disfarçada.

Na reexecução, comparar **base usada + estado vivo + proposta**. Se o campo vivo mudou, não sobrescrever silenciosamente; reconciliar a edição e revisar de novo. Comentários, tags e campos não traduzidos ficam fora da escrita. A mesma proposta já aplicada resulta em nenhuma operação. Nova edição do deck externo não substitui automaticamente a tradução NEBLI. Desfazer restaura somente campos atribuíveis à tradução, com checagem de conflitos; jamais restaurar a coleção inteira por causa de uma frase.

## Aceite e próxima implementação

Primeiro, uma amostra com mecanismo, contraste, termo clínico, cloze `c2`, irmãos de uma nota e identificação visual. Testar também os casos que devem ser recusados: cloze renumerado, negação perdida, mídia alterada, nota editada depois do plano, modelo não suportado e nota cuja edição ressuscita irmão anteriormente retirado.

Comparação do conjunto de IDs no Anki é indispensável: apenas manter os marcadores existentes não prova que uma edição não regenerará card retirado. Essa verificação deve ocorrer primeiro em perfil de teste isolado; não recriar apagados para “completar” a tradução.

Depois, lote delimitado na próxima aula, mantendo identidade e colhendo feedback de uso já previsto no projeto. A amostra textual local desta arquitetura está em `arquivos-trabalho/nucleo-traducao-2026-09-28/`; não é piloto instalado, renderização certificada, revisão científica integral ou migração pronta. Não alterar cores como efeito colateral de traduzir.
