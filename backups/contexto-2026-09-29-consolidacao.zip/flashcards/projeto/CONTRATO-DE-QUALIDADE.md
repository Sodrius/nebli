# E1 + cards prontos para estudar — contrato de qualidade

Revisão consolidada 25/09/2026. Política única em README.md; regressões em FEEDBACKS.md; retenção em BANDEIRAS-E-PROGRESSAO.md. Davi quer estudar com confiança, sem assumir a função de curador. As verificações são responsabilidade do executor. Não certificam retroativamente a coleção.

**Entrega somente de cards explicitamente solicitada:** itens de E1, seção E1 da matriz e publicação de E1 ficam `não aplicável`, sem reduzir os critérios de qualidade dos cards. Para o ciclo UC08 de 29/09, seguir [RECONSTRUCAO-UC08](RECONSTRUCAO-UC08.md); não exigir apostila nem compilador para liberar a aula.

## Três perspectivas sobre o mesmo assunto

| Perspectiva | O que verificar | Evidência de inclusão |
|---|---|---|
| Aula | Conceitos, relações, mecanismos, reconhecimento visual e aplicações realmente ensinados/exigidos, incluindo prática | Objetivo e localizador no material docente/roteiro, prova pertinente ou anotação disponível |
| Steps/residência pertinentes | Perguntas fundamentais do **mesmo conceito** que merecem recuperação mesmo se o slide for superficial | Card/recurso/questão efetivamente lido, relação explícita com um alvo da aula e justificativa do ganho; sem frequência inventada |
| Compreensão durável | Relações que permitem explicar o mecanismo, distinguir conceitos, reconhecer a estrutura e deduzir consequências | Explicação bibliográfica/docente verificável e descrição do que a relação permite compreender |

São dimensões da auditoria, não três decks, cotas ou rótulos de prioridade nos cards. Uma pergunta pode atender às três. Não somar percentuais ou contar o mesmo card três vezes.

**Interpretação operacional do pedido atual:** a aula delimita o assunto **e os alvos** (F-C15). O slide não é teto para *explicar* um alvo que a aula trouxe: o mecanismo por trás de uma figura mostrada, ou o que muito provavelmente foi dito, pode entrar mesmo sem a formulação literal no slide. Fato adjacente de Step 1/livro que a aula não trouxe (toxicidade, espectro, inverso, doença lateral) sai — não vira azul nem subdeck, **salvo a pequena ponte clínica story teller explicitamente autorizada abaixo em 28/09**. Permanece o filtro contra cadeias de clínica lateral e antecipação de blocos futuros.

### Card “story teller” e aplicação clínica

Davi corrigiu a interpretação do executor: **story teller ensina e relembra, sem necessariamente ser caso, história ou narrativa**. Aprender pelo AnKing real, conforme ESTILO-ANKING. Pode ser uma pergunta atômica cuja formulação e resposta ensinem uma relação. Não inflar frentes nem supor tolerância a parágrafos a partir do nome; Q10 foi rejeitada, não ficou aguardando resposta.

A aplicação clínica pode ser de qualquer tipo que Davi já consiga captar e esteja **DIRETAMENTE relacionada à aula**, de modo ocasional e importante. O contexto mínimo fica no próprio card; pode haver alguns elementos relacionados se forem compreensíveis, sem importar uma cadeia clínica nova. Aplicações mais extensas que só acrescentem cards azuis são algo a evitar. A pequena relação pode não estar literalmente no slide, desde que se apoie diretamente na base da aula. Isso refina F-C15; não revoga a reprovação do deck de Edema excessivamente clínico.

Registrar: fundamento da aula → relação diretamente vinculada → alvo recuperado → fonte/explicação suficiente. Sem cota de story tellers. **Manter um bom card básico e preferir a aplicação no verso, salvo ganho excepcional de recuperação própria (Q11C).** Para boa frente AnKing, preferir apoio no verso a reescrever a frente (Q12B); erro e ambiguidade reais continuam corrigíveis. Busca AnKing/externos continua antes de autoria; não produzir uma série autoral clínica por reflexo.

Para incluir um complemento, registrar fora do card:

1. A qual alvo específico da aula ele se liga?
2. Qual relação adicional precisa ser lembrada ou compreendida, e qual fonte a sustenta?
3. Por que não basta o verso de um card já selecionado?
4. Por que vale estudar isso agora, sem importar uma cadeia de assuntos novos?

Se essas respostas não forem convincentes, usar apoio breve no verso/guia ou registrar para uma aula futura. “Cai no Step”, “é útil para a vida”, “é HY” e “aparece na figura” não são justificativas suficientes isoladamente. Também não retirar uma boa relação essencial só porque não foi escrita no slide.

AnKing-first continua sendo a ordem de busca. Autoria continua excepcional: complementar Step 1 não abre uma nova frente de produção autoral. Uma lacuna importante de compreensão só recebe autoria após busca em AnKing e outros acervos acessíveis, com fonte, alvo focal e avaliação de carga.

## Verificação que o executor deve fazer

### Fidelidade às preferências de Davi

Cumprir README § O que Davi quer e a entrada de EXECUCAO-DECK-AULA em cada sessão. A revisão precisa apontar decisões concretas que preservam os critérios calibrados; estética do executor, concisão máxima ou prudência excessiva de verdes não substituem a intenção do usuário. Regressões do par FI08/BT03 (F-C44) impedem aceitar uma nova versão só porque ficou maior ou menor. Dúvida nova de gosto/escopo deve ser exposta com exemplos antes de virar regra do lote, sem reabrir decisões explícitas.

UC03 é a referência positiva reafirmada por Davi: preservar o que funciona e aplicar os ajustes pedidos, conforme MEMORY/ESTILO. O executor responde pela calibração do total e das bandeiras contra conteúdo e valor longitudinal; não perguntar ao aluno se a quantidade está correta (F-20260929-CLAUDE-01). O questionário amplo foi pedido para preferências, não para delegar auditoria médica a Davi.

### Fontes e recorte

- Procurar roteiro prático, material em pastas relacionadas, anotações e provas pertinentes; não concluir “não existe” após olhar apenas a pasta do slide.
- Distinguir não localizado, inacessível e consultado. Determinar se a ausência pode alterar o recorte; trabalho parcial não vira cobertura completa por falta de acesso.
- Separar objetivos teóricos e visuais na matriz, mesmo se a apresentação final for um único deck.
- Fazer varredura de toda a fonte disponível, ligando cada bloco da aula à cobertura ou a uma exclusão específica justificada. Conferir apenas os objetivos que o próprio executor escolheu não demonstra cobertura completa; menção no verso não substitui reconhecimento/recuperação quando esses são necessários.
- Conferir exclusões e a distribuição de atenção: muitas perguntas sobre um detalhe molecular não compensam ausência de uma estrutura central.

### Busca e seleção

- Verificar cada pergunta e cada cloze selecionado, incluindo os irmãos de notas compartilhadas.
- Para lacunas importantes, reformular buscas e consultar os acervos adequados antes de autorar. Resultado vazio ou excesso de falsos positivos é motivo para revisar a busca.
- Conteúdo suficiente no verso conta para aprender. Se o objetivo é identificar, distinguir ou responder sem ajuda, comprovar também a pergunta/imagem de recuperação correspondente.
- Não incluir duas recuperações equivalentes da mesma informação. Comparar alvo, resposta e habilidade em toda a seleção e nos compartilhados, inclusive autoral vs AnKing. Par mantido exige ganho explícito de direção, contraste ou reconhecimento; outra redação ou tag diferente não bastam. Registrar exclusões, sem remover silenciosamente cards já existentes/revisados.
- Exceção de anatomia (Davi, 28/09): várias práticas da mesma estrutura são permitidas; **somente um representante verde por estrutura**. Preferência de acervo: AnKing → outros de anatomia → AnatoKing. Registrar grupos e representante, verificar figura/destaque e ampliar imagens do AnatoKing. Outros cards válidos podem ficar azuis; erro não vira “opcional”.
- Revisar todos os autorais quanto a foco, precisão, tamanho, aparência, imagem útil e ausência de comentários de curadoria no verso. Quantidade alta motiva reexaminar busca e escopo, sem cota percentual.
- Para novos autorais, alvos distintos que mereçam recuperação própria favorecem perguntas separadas, atômicas e autocontidas (Q13C/Q14A); não reunir tudo sob uma resposta grande para reduzir contagem. Isso não autoriza dividir automaticamente notas já revisadas. Estudar padrões e limites em ESTILO-ANKING, sem transformar média de palavras em requisito.

### Precisão e apresentação

- AnKing e outros decks são candidatos, não autoridade infalível. Verificar contradições entre pergunta, Extra, imagem e bibliografia; corrigir somente a cópia NEBLI quando houver fundamentação.
- Ler o verso renderizado, inclusive campos herdados. Remover conteúdo lateral sem retirar apoio necessário a outra aula associada ao mesmo card.
- Inspecionar cada imagem de autoria/adaptação e os alvos visuais selecionados; mídia presente no APKG não prova legibilidade ou pertinência. Amostragem pode diagnosticar um lote, mas não certifica imagens ainda não vistas.
- Preferências visuais Q15–20: negrito econômico/aparência AnKing nos autorais; preservar bons mnemônicos existentes, **não inventar mnemônicos**. Imagem anatômica inteira como principal, grande e com ampliação acessível; clareza e reconhecimento em imagem real guiam a escolha. Quando a identificação histológica depende de detalhe/contexto, detalhe na frente e visão geral no verso. Rótulos embutidos em imagens continuam em inglês.
- Indicações de vídeo exigem correspondência real com o alvo. Canal e título confirmados não provam cobertura; timestamp só quando sustentado por capítulo, transcrição ou inspeção. Declarar a limitação quando apenas indicado.
- Metadados, fontes de decisão e justificativas de inclusão ficam no relatório. Não acrescentar rodapé meta nem novos significados de bandeira.
- Quando houver tradução PT-BR, cumprir TRADUCAO-DOS-CARDS: conteúdo integral, formatação/negritos/HTML/tags preservados, mesma recuperação, terminologia conferida, negações/condições/valores preservados, nenhuma pista nova, revisão de todos os irmãos e renderização. Tradução, correção científica, limpeza e alteração didática têm decisões registradas separadamente.

### Entrega e manutenção

- Conferir a seleção visível ao estudante, incluindo cards compartilhados: associar a nota por tag não prova que só os clozes pertinentes aparecem.
- Preservar identidade, histórico, comentários, marcas pessoais e originais. Reexecutar a aula deve atualizar a mesma seleção, sem duplicar revisões.
- Separar verificação técnica e revisão de conteúdo. Uma contagem correta, ausência de erro no script ou APKG válido não certificam o conteúdo.
- E1 e guia por aula; APKG comprimido da UC inteira, sem bandeiras no arquivo e sem alterar flags vivas. Seguir PUBLICACAO-POR-UC.md. Upload APKG continua pausado; se reautorizado, atualizar o mesmo file_id com readback de destino/nome/tamanho/permissão. Verificar IDs únicos/compartilhados/mídia. Não restaurar cards apagados de artefatos antigos.
- Corrigir problemas identificados pelo próprio executor antes de pedir feedback. Não transferir ao aluno uma checagem card por card como rotina de aceitação.

### E1, autoria e retenção — aceite separado
- E1 explicativa efetivamente revisada (ou boa existente conferida), segundo didatica/E1.md: mecanismos corretos, encadeamento, termos definidos, imagens que ensinam e economia sem perda de profundidade. Não substituir por guia nem reativar E2/E3.
- Uma matriz de objetivos atende E1 e cards: indicar seção explicativa e card/cloze/verso; não impor bijeção de frase e card. Revisar lacunas **e excessos**.
- Cada autoral identifica a lacuna relevante, duas rotas AnKing distintas, externos adequados realmente buscados e candidatos recusados com motivo. Coleção inacessível não equivale a resultado zero. Alta autoria pede segunda auditoria de busca/escopo. Registro burocrático sozinho não prova boa busca.
- Classificar cada novo card após qualidade/deduplicação: verde, azul ou incerteza fundamentada, preservando feedback/marcas pessoais. HY literal não é condição. Registrar utilidade futura e relação com currículo/Step quando pertinente, sem inventar estatística.
- Núcleo delimitado por importância; **40 é referência de calibração, não regra de aprovação ou cota**, conforme esclarecimento final de Davi. Conferir fundamentos faltantes e verdes sem necessidade de recuperação própria; não reclassificar apenas para ajustar uma média. Anatomia/fisiologia recebem atenção especial, não aprovação automática de detalhes. Compartilhado é um único card e não recebe maior prioridade por estar em duas aulas.

## Fechamento obrigatório por execução

Adicionar `REVISAO-DE-QUALIDADE.md` na **mesma pasta da execução**; não criar outra árvore de documentação. Usar o formato abaixo, preenchendo com evidências reais:

```text
Aula / run_id / versão do escopo e da seleção:
Fontes consultadas (com páginas/trechos):
Fontes ausentes e impacto:
Aplicação do padrão de Davi: decisões/candidatos → feedback ou exemplar pertinente
                            → resultado; dúvidas novas discutidas e ainda pendentes
Feedbacks considerados: IDs → aplicação/verificação ou pendência; incluir os recebidos
                       pelo outro executor até o fechamento, sem presumir aceite
Varredura da fonte integral: blocos/páginas/figuras → alvos cobertos ou exclusão justificada

Alvo | origem (aula/Step/compreensão; pode ser múltipla)
     | evidência na fonte | card/cloze ou verso/imagem
     | aprendizagem suficiente? | recuperação ativa necessária e presente?
     | pendência ou exclusão justificada

Revisão do recorte: resultado, evidência e exceções
Revisão Step do mesmo assunto: resultado, candidatos incluídos/excluídos e motivo
Revisão dos mecanismos/contrastes/identificação: resultado e evidência
Revisão de excessos e redundância: pares comparados, ganhos e decisões
E1: seções, precisão, didática, figuras, PDF/limitações
Autoria: lacuna → buscas/candidatos recusados → alvo da nova pergunta
Retenção: alvos do núcleo → cards; verde/azul/incerto → motivo específico
          lacunas/excessos conferidos; verdes únicos novos/compartilhados
Tradução, se houver: versão/idioma → revisão de significado/estrutura/visual
Revisão de autorais, versos, imagens e nomenclatura: resultado e correções
Seleção acessível, identidade, histórico, mídia e APKG: referência ao recibo

Estado do conteúdo: revisado / parcial / não verificado
Estado técnico: verificado / parcial / não verificado
Estado de acesso: Anki local / sincronização confirmada ou não testada
Pendências que afetam o estudo:
Contabilidade: notas, cards únicos, novos/reutilizados/compartilhados,
             origens reais, autorais, verdes, azuis, incertos,
             marcas de feedback/pessoais e suspensos
```

Não usar campos genéricos “OK” sem evidência. Uma fonte importante indisponível, lacuna relevante ou contradição não resolvida mantém o conteúdo parcial. Não inventar porcentagem de cobertura curricular Step 1 por contagem de tags HY. Não prometer domínio, ausência absoluta de erro ou sucesso na prova.

“Pronto para estudar no perfil X” exige conteúdo revisado e estado técnico verificado para a mesma versão. Uso em outro dispositivo só é confirmado após verificação naquele dispositivo. Mudanças em fontes, seleção ou campos invalidam as partes afetadas da revisão.

Na conversa, mostrar apenas o necessário: onde estudar, o que a seleção cobre, eventual pendência que muda o estudo e contabilidade breve. O relatório detalhado permanece disponível para auditoria, sem exigir que Davi o leia para começar.

## Atenção aos verificadores legados

`flashcards/scripts/verificar_cobertura_deck.py` procura palavras em campos de notas e calcula semelhança textual. Serve como alerta de busca/lacuna, **não como aprovação semântica**. Seu resultado “GATE OK” não substitui este fechamento; não comprova cobertura por card/cloze, pertinência do verso ou reconhecimento visual.

Após a limpeza manual, os recibos antigos são históricos, não evidência de cards presentes. Reconciliar pendências por identidade viva; não recriar card apagado para resolver comentário antigo.

O comando genérico completo permanece em implementação. Este contrato torna o fluxo assistido verificável; sua existência não significa que as aulas já instaladas passaram pela revisão atual.
