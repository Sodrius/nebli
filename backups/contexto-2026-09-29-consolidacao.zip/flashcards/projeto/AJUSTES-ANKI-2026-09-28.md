# Ajustes finos do Anki — 28/09/2026

## Entendimento do pedido

Davi quer decks bons de cada aula, com pequenos ajustes sobre o que já funciona. O acervo pode ser mais amplo que o estudo diário: conteúdo válido e útil pode ficar disponível mesmo quando não vale mantê-lo em revisão por anos. Isso exige separar **cobertura da aula, qualidade do card e importância para retenção**. A bandeira não substitui nenhuma dessas avaliações.

Verde significa recomendação segura de manutenção. Azul é conteúdo bom com menor custo futuro de esquecer; branco exige dúvida concreta registrada. Imagem deve permitir reconhecer a estrutura ou compreender o mecanismo. Frente curta cobra um alvo; verso curto explica a relação causal. Não transformar a melhoria em reconstrução dos decks ou expansão clínica lateral.

Decisão adicional de anatomia: **AnKing → outros acervos anatômicos → AnatoKing**. Várias práticas da mesma estrutura podem coexistir, mas apenas uma é o representante verde. A aplicação considera o alvo cobrado, não qualquer órgão mencionado no contexto. Não pressupõe que todo AnKing seja melhor que qualquer alternativa sem ler a nota.

## Aplicado e conferido no perfil Mac `User 1`

| Ajuste | Resultado |
|---|---|
| Conteúdo e comentários | 16 notas alteradas, abrangendo 24 cards. Explicações de ferro/hepcidina/fermentação; simplificação de tempo de geração, halotolerância, criptas e células caliciformes; Godet com mecanismo; correções factuais encontradas na amostra. |
| Acabamento do verso | Quatro dessas notas receberam um segundo ajuste após renderização: complemento por Fur e imagens de apoio recolhíveis; figura de ferro com texto distorcido retirada da exibição, mantendo o arquivo original e o backup. |
| AnatoKing | Modelo das 53 notas/cards NEBLI: imagem principal sempre visível, até 100% da largura, proporção preservada; retirado o salto automático até o botão. Extra curto fica visível. Os 52 arquivos de imagem foram vistos em pranchas de inspeção. |
| Alvo visual | Orifício pilórico: substituída a figura que destacava o canal por figura existente do esfíncter, com pergunta que explicita a relação. Esquema de pregas do íleo: segmento fornecido como contexto, pois não é identificável por aquele desenho genérico. |
| MCAT | CSS das 17 notas/36 cards NEBLI alinhado ao padrão AnKing usado no projeto; campos e histórico preservados. |
| Dope Anatomy | CSS dos 51 cards NEBLI desse modelo com imagens responsivas e contraste no modo noturno. |
| Bandeiras | 211 cards no plano delimitado; 144 bandeiras alteradas. A coleção inteira não foi recolorida. |
| Anatomia repetida | 23 grupos de estruturas com um único representante verde por grupo; conferência por ID no estado posterior. Ex.: papila maior favorece AnKing; estômago favorece Dope sobre AnatoKing; artérias já presentes no AnKing ganham precedência sobre versões redundantes. |
| Add-on de totais | Reparada instalação no Mac que estava sem `config.json`. O instalador passou a preservar metadados e opções pessoais ao reinstalar. |

Os 1.537 IDs de cards foram preservados. Agendamento, repetições, intervalos, suspensões e dificuldade/ease conferidos antes/depois da escrita, sem diferenças. Nenhum card foi adicionado, apagado, suspenso ou dessuspenso. Originais nos acervos de referência não foram editados. O sync com AnkiWeb retornou sem erro; chegada no tablet não foi observada.

Estado de cores após o lote: 486 verdes, 222 azuis, 826 sem bandeira e 3 vermelhos. **Os brancos restantes não foram certificados como avaliados:** grande parte está fora desta calibração incremental. O usuário estudou durante a sessão; eram 224 cards com respostas no snapshot inicial e 231 na leitura antes/depois da aplicação.

## Pendências reais

- Dois AnatoKing da região pilórica usam a mesma figura destacada com respostas diferentes; foram marcados em vermelho para reconciliação do alvo. Não são declarados corretos por terem imagem.
- O card comentado de AGCC recebeu correção e explicação, mas permaneceu vermelho por possível recuperação equivalente em outra aula; falta resolver associação/duplicação preservando o histórico.
- Cobertura: não foram criados cards nesta manutenção. As lacunas propostas de Edema ainda precisam de confronto com o material da aula e buscas de acervo; a triagem de frentes não prova ausência de conteúdo.
- A substituição sistemática de AnatoKing por candidatos melhores não foi executada. A preferência foi aplicada aos representantes já existentes e registrada para seleção futura; falta busca por estrutura onde só existe AnatoKing.
- Há uma triagem preliminar do restante das frentes, com dúvidas de precisão/escopo. Não é auditoria bibliográfica integral nem plano para migrar todas as bandeiras.

## Rotina e próximas funcionalidades

- **400 respostas totais/dia, novos + revisões; cramming separado.** Não são 400 novos nem 400 cards únicos. O preset vivo estava com limites 9.999/9.999 e foi preservado. A calibração de novos, retenção desejada e carga ainda exige dados de revisão; não foi simulada por alteração arbitrária de limites.
- **Sanguessugas:** zero `tag:leech` em toda a coleção aberta, zero lapses no snapshot dos cards NEBLI e zero suspensos no NEBLI médico. Não houve cards elegíveis para dessuspender. Quando existirem: analisar histórico e causa, explicar/corrigir o alvo e só então reativar os que couberem, preservando suspensões pessoais alheias à sanguessuga. O [manual do Anki](https://docs.ankiweb.net/leeches.html) descreve a detecção por falhas repetidas e a necessidade de tratar a causa.
- **Bibliografia:** a [pasta Livros](https://drive.google.com/drive/folders/1ZYH9ezNk8lH4h0ArsX2PgdOpsnf4N-ss) já existe. Robbins, Trabulsi, Janeway, Netter e Williams confirmados por metadados; IDs canônicos atualizados. Isso não prova leitura dos PDFs nem acesso do Claude nessa outra aplicação.
- **Macros:** ABNT2 confirmado; Davi pediu para deixar para depois.
- **Ordem da aula:** desejada tanto na progressão inicial quanto no painel. Ainda não implementada; deve preservar o agendamento das revisões e mapear a sequência docente por card/cloze.
- **IA no card:** requisito de explicação fácil e contextual, apoiada na bibliografia. Não há novo add-on de IA entregue nesta execução; o add-on reparado é o de totais de decks.
- **Voltar no tablet:** no AnkiDroid, o botão **Desfazer** retorna à resposta anterior e desfaz a avaliação; não é apenas navegação sem efeito. [Manual oficial do AnkiDroid](https://docs.ankidroid.org/#_study_screen).

## Evidências e fontes

Artefatos privados em `arquivos-trabalho/ajustes-anki-2026-09-28/`: `snapshot.json`, backup SQLite consistente `collection-before.anki2`, `plan.json`, `recibo.json`, `acabamento-recibo.json`, `cards-before-compact.json`, `cards-after-final.json`, `bandeiras.json`, `anatomia-estruturas.json`, contatos das imagens e previews renderizados. Dados de cards e imagens continuam ignorados pelo Git público. `triagem-frentes-NAO-APLICAR.json` é preliminar e não deve ser executado como classificação geral.

O plano registra fonte por alteração. Principais conferências: [metabolismo bacteriano](https://www.ncbi.nlm.nih.gov/sites/books/NBK7919/), [hepcidina](https://www.ncbi.nlm.nih.gov/books/NBK538257/), [sideróforos/Fur](https://pmc.ncbi.nlm.nih.gov/articles/PMC6487204/), [crescimento bacteriano](https://openstax.org/books/microbiology/pages/9-1-how-microbes-grow), [peróxido/catalase/peroxidase](https://openstax.org/books/microbiology/pages/9-2-oxygen-requirements-for-microbial-growth), [cetogênese](https://www.ncbi.nlm.nih.gov/books/NBK493179/?report=reader), [linhagens epiteliais intestinais](https://www.ncbi.nlm.nih.gov/books/NBK26875/), [congestão versus hipoperfusão](https://pubmed.ncbi.nlm.nih.gov/32897746/) e [edema](https://www.ncbi.nlm.nih.gov/books/NBK348/). Fontes abertas foram usadas nas correções; não declarar que Robbins/Trabulsi foram lidos nesta manutenção.

Testes do instalador e operação de decks: 16 testes passaram. Readback do Anki validou campos, modelos, bandeiras e invariantes de agendamento. A revisão visual usa HTML renderizado pelo Anki em WebKit, incluindo larguras de 820 e 390 px; não equivale a teste no aplicativo físico do tablet.
