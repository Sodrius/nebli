# Retomada no Claude — padrão de Davi em cada sessão

O objetivo é produzir o deck-aula na qualidade definida por Davi nas calibrações. Não redesenhar a seleção ou o estilo conforme uma preferência nova do executor. A intenção e os critérios estão em [README § O que Davi quer](README.md#o-que-davi-quer); a execução deve demonstrar essa aplicação com decisões reais, conforme [EXECUCAO-DECK-AULA](EXECUCAO-DECK-AULA.md).

**Começar também por [MEMORY § O projeto que Davi quer](../../MEMORY.md#o-projeto-que-davi-quer--recuperar-antes-de-produzir).** Davi explicitou que a **UC03 é a base mais calibrada**: quer aperfeiçoamento desse resultado, cobertura de toda a aula, bandeiras no que vale reter e bons cards clínicos storytellers. A reconstrução UC08 não zera as preferências. Não apresentar outra filosofia de seleção nem pedir que Davi decida quantidade de cards/verdes.

## O que está preparado para a próxima mensagem

- [100 perguntas A/B/C/D](CALIBRACAO-DECK-100-PERGUNTAS.md), solicitadas por Davi para revisar entendimento e memória, com histórico e leitura atual em cada tema. **Sem respostas nesta preparação.** Se ele responder, preservar por Q-ID e incorporar conforme o protocolo do arquivo; não preencher o restante por palpite. Não reenviar o formulário inteiro espontaneamente.
- Se ele pedir um deck por mensagem comum, seguir a mesma entrada abaixo; não exigir comando especial nem que cole este handoff. Aplicar decisões vigentes e respostas já recebidas. Se pedir só planejamento/calibração, não começar outra aula por efeito colateral.
- Todo feedback que você receber vai ao registro comum FEEDBACKS **nesta sessão**, inclusive elogio, crítica local ou resposta parcial. Registrar antes de encerrar/seguir a próxima aula, atualizar critério e síntese do MEMORY quando pertinente; na entrada e antes da entrega, reler os registros novos do Codex. Não depender da memória privada do chat.
- As fontes e propostas antigas de monitor/tutor/painel/macros/Step foram recuperadas no MEMORY e nas perguntas 41–50/71–90. Distinguir desejo, decisão e função implementada; não reativar e-mail, regras antigas de bandeira/suspensão ou infraestrutura Windows por inferência.

## Entrada obrigatória em toda sessão

1. Ler MEMORY (intenção e estado) e README → FEEDBACKS → BANDEIRAS-E-PROGRESSAO → CONTRATO-DE-QUALIDADE. Recuperar as respostas literais abaixo se houver conflito de interpretação; não pedir novamente preferências disponíveis fora da reconferência explicitamente solicitada no questionário.
2. Ler ESTILO-ANKING, incluindo a referência positiva UC03, e o caso pertinente antes de selecionar/escrever; TRADUCAO-DOS-CARDS antes de traduzir. Antibióticos v3 foi aprovado; o piloto de Edema excessivamente clínico foi reprovado e a base restaurada. Vascularização é referência visual. FI08/BT03 iniciais foram criticados por pouca cobertura e frentes longas. Contagens e cores antigas não são metas.
3. Ler EXECUCAO, OPERACAO e ACERVOS; PUBLICACAO ao empacotar; didatica/E1 somente se a entrega incluir E1. Estado da tarefa na fila vigente e MEMORY, conferido nos artefatos e no perfil vivo.
4. Na revisão da aula, mostrar como candidatos/decisões concretos atendem aos critérios de Davi: cobertura, acervos alternativos, autoria, imagens, livro, núcleo e tradução. Não basta afirmar que leu os documentos ou que um script passou.

## O que não pode se perder na passagem

- Cobertura completa dos alvos relevantes da aula, incluindo prática; sem teto de cards. Não reduzir cobertura para deixar o deck enxuto nem criar autoria para detalhe ilustrativo sem importância.
- Buscar AnKing e acervos alternativos adequados antes da autoria. Preservar boas recuperações, inclusive irmãos pertinentes; avaliar ganho real de pares sem corte automático por semelhança.
- Autoral AnKing-like: recuperação focal, contexto mínimo, redação natural e curta, aparência consistente; ensina e relembra sem exigir história. Comparar com AnKing real. Imagem preferencialmente de card AnKing; depois slide/fonte externa adequada.
- Consultar bibliografia por aula, com trecho efetivamente lido ou substituto/limite declarado. Fonte aprofunda o conteúdo da aula, sem expandi-lo para outro bloco.
- Verde pelo valor duradouro do alvo, sem contagem desejada. Não confundir núcleo com toda a seleção disponível nem rebaixar fundamento só porque o modelo acha dedutível.
- PT-BR fluido e fiel: preservar conteúdo, formatação, mídia, tags e recuperação da base aprovada. Curadoria/correção têm etapas próprias. Não declarar tradução excelente sem comparação e renderização da versão entregue.
- Manter a direção já calibrada. Uma ambiguidade nova de gosto/escopo recebe exemplos concretos e recomendação para Davi antes de virar regra do lote; ele não precisa auditar todos os cards.

## Trabalho atual — UC08 em 29/09

[RECONSTRUCAO-UC08](RECONSTRUCAO-UC08.md) é a fila vigente. **Sem E1; motilidade P1, secreções P2.** Claude executa todas as matérias; Codex administra/revisa. Originais e outras UCs preservados.

FI08 e BT03 foram instalados pelo Claude; F-C44 rejeitou a primeira cobertura/forma, e o Claude já relata correção **v3/v3c** nos artefatos atuais. Não executar novamente a v1 nem presumir correções ainda não iniciadas. Leitura pontual de nomes no Anki viu FI08 47/BT03 49 cards; isso não certifica conteúdo/tradução. Conferir planos, campos e recibos da mesma versão antes de qualquer ajuste. Revisão Codex integral ainda não registrada.

**Feedback posterior já recebido pelo Claude:** F-20260929-CLAUDE-01 (antes rotulado F-C45, colisão resolvida) manda o executor calibrar completude pela aula e verdes pelo valor duradouro/Step; Davi não sabe julgar os totais. Sobre autorais, disse “pelo que vi por cima, sim”, sem aprovar integralmente conteúdo/tradução. Incorporar essa fala à revisão do par; não voltar a perguntar se quantidade/verdes estão bons. Produção seguinte depende do pedido ativo e do estado reconciliado da fila, sem transformar falta de auditoria técnica pelo aluno em bloqueio.

F-C43 estabelece o ritmo: Claude faz revisão própria e instala cada aula; Codex revisa a versão instalada, e os ajustes preservam histórico. **A cada dois decks, parar para o retorno de Davi antes de começar o próximo par.** Incorporar o retorno efetivamente recebido; não exigir dele certificação de cobertura ou das bandeiras. O pedido atual de preparar contexto/questionário não executa uma aula por si só.

Toda escrita Anki por `nebli.decks.escrita()`, com backup, lock, diário e readback. Não executar scripts antigos como gerador universal; não restaurar APKGs históricos. APKG local por UC e sem flags no arquivo; upload pausado. Relatar conteúdo, instalação, sync e acesso remoto separadamente. Nenhum orquestrador entre sessões foi instalado por este handoff.

## Evidência de preferências já recebidas

- [Decisões de 22/09](../../arquivos-trabalho/arquitetura-nebli-decisoes-2026-09-22.md): objetivo, cobertura sem teto e distinção entre disponibilidade e manutenção; escolhas posteriores de idioma/ritmo/E1 prevalecem.
- [Respostas literais de 23/09](../../arquivos-trabalho/calibracao-escala-2026-09-23/RESPOSTAS-ORIGINAIS.md): acervos antes de autoria, teoria + identificação, qualidade e transferência para Claude (Q30).
- [Respostas literais de 28/09](../../arquivos-trabalho/nucleo-traducao-2026-09-28/RESPOSTAS-2026-09-28.md): significado de story teller, escrita AnKing, imagens, tradução, núcleo e perguntas clicáveis.
- FEEDBACKS mantém evolução e decisões recentes. Separar fala literal, interpretação do executor e evidência de aplicação. Ausência de arquivos privados num clone não apaga as preferências consolidadas nos documentos canônicos.

A documentação deve impedir perda de contexto; sua existência não prova que o deck resultante atingiu a qualidade pedida. Conferir cada entrega e corrigir regressões antes de repetir a estratégia.
