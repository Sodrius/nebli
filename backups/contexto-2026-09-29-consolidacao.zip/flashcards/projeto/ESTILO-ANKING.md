# Escrita AnKing e o “story teller” de Davi

Calibração de 28/09/2026, após as respostas da leva de 32 perguntas. Subordinada a README/CONTRATO. Estudo descritivo de escrita; não é aprovação científica de todo o AnKing nem seleção para uma aula.

## O pedido que guia a leitura

Davi chamou de story teller o card que **ensina e relembra**. Ele pediu estudar tamanho, escrita, fluidez, conteúdo e atomicidade no acervo real. Rejeitou a interpretação do executor de transformar o estilo em casos clínicos/narrativas e a pergunta sobre quantas frases ou parágrafos toleraria. Não fixar esse formato nem perguntar novamente sobre uma premissa rejeitada.

No NEBLI, procurar uma pergunta que recupere um alvo pequeno dentro de uma afirmação compreensível. A leitura da frase completa ensina uma relação; o verso acrescenta o porquê ou um contraste que faça diferença. Isso pode acontecer em uma frase declarativa, uma pergunta direta ou uma identificação visual. Nem todo card precisa contar uma história, ganhar um mecanismo novo ou ter um verso longo.

## Calibração em cada execução — reforço de Davi em 29/09

Antes de fechar autorais/adaptações, comparar com exemplos reais deste estudo e candidatos AnKing do assunto: o que fica visível, o que se oculta, quantas respostas independentes se cobram, como o contexto ensina e o verso ajuda. Registrar a comparação no relatório da aula; não repetir o estudo de mil notas nem inventar uma quota de exemplos. Um modelo AnKing aplicado a uma lista longa não resolve a escrita. Procurar uma frase curta e fluida quando ela basta, sem transformar isso em corte mecânico de palavras ou mutilar uma boa frente existente.

O contraste é o resultado de FI08/BT03 relatado em F-C44: cobertura pequena coexistiu com frentes longas. A correção exige recuperar alvos relevantes e melhorar perguntas, não escolher entre “poucos cards gigantes” e “muitos detalhes sem valor”. “Ensina e relembra” deve ser visível na recuperação concreta; não exige inventar caso, mnemônico ou nova aplicação clínica.

Imagem de autoral: procurar primeiro figura pertinente nos cards AnKing, depois no slide e em fonte externa adequada. Conferir alvo, contexto, legibilidade e proveniência; preferência de origem não torna qualquer imagem correta. Bibliografia sustenta o conteúdo. Fonte e imagem ficam registradas por card, com motivo quando a primeira opção não atende.

## UC03 como referência positiva — 29 de setembro

Davi indicou **o conjunto dos decks UC03** como mais próximo do resultado desejado; não nomeou um favorito nesta rodada. Essa é a base de experiência/cobertura a preservar e melhorar, com os ajustes de autoria, tradução, imagens e retenção já registrados. Não interpretar essa preferência como aprovação científica de cada card, autorização de restauração antiga ou meta de contagem.

| Referência rastreável | O que aprender para a próxima execução | Limite da evidência |
|---|---|---|
| Antibióticos e resistência, versão v3, F-C15: “agora sim gostei” | Seleção abrangente **do conteúdo da aula**, com aplicação e profundidade pertinentes; corrigir expansão para outros assuntos sem transformar a aula em resumo mínimo | `arquivos-trabalho/deck-aula-antibioticos-2026-09-24/MAPA-ESCOPO.md` e `ESTADO.md` são preparação antiga, com opções depois rejeitadas. Não usá-los como seleção v3 nem reexecutar seus planos |
| Edema e congestão, versão anterior restaurada após o piloto de 25/09; F-C20/F-C21 | Manter mecanismos, morfologia e sinais pertinentes como o exemplo Godet; melhorar cards pontualmente. A versão excessivamente clínica foi rejeitada | Relatório de 24/09 em `arquivos-trabalho/deck-aula-edema-congestao-2026-09-24/RELATORIO-X4.md`; cores/limites históricos não são os de hoje; autorais e fontes ainda podem precisar dos ajustes já pedidos |
| Inflamação aguda UC03, relatório X2 de 24/09 | Examinar a distribuição entre sinais, mudanças vasculares, recrutamento, efeitos, desfechos e morfologia: foco numa parte não compensa outra ausente | `arquivos-trabalho/deck-aula-inflamacao-aguda-2026-09-24/RELATORIO-X2.md` descreve execução; não é aceite individual de todos os cards nem restauração autorizada |
| Escrita do AnKing real, estudo de 28/09 abaixo | Frente/ocultação/verso que ensinem uma relação sem exigir narrativa; usar para aperfeiçoar o que já funcionava na UC03 | Referência de forma e recuperação, não autorização para importar conteúdo lateral |

Antes de escolher nova estratégia, abrir cards pertinentes da UC03 viva e do AnKing, comparando contexto, resposta exigida, fluidez, verso e distribuição de alvos. Registrar IDs/versão e o que preservar/melhorar na revisão da corrida, sem copiar textos privados para o repositório público. Se a coleção estiver inacessível, usar as evidências disponíveis e declarar o limite; não afirmar comparação visual viva que não fez. Não repetir um estudo de mil notas por aula.

A preferência pela UC03 significa **continuidade com melhoria**, não que seus números, sua proporção de autoria ou suas bandeiras antigas sejam um molde. Cobertura e retenção são calibradas pelo executor contra a aula e a utilidade futura; não perguntar ao aluno quantos cards/verdes deveriam existir (F-20260929-CLAUDE-01).

## O que foi observado

Base: AnKing Step instalado, 28.649 notas no recorte. Amostra aleatória uniforme de 1.000 notas (semente 20260928), correspondendo a 1.196 cards no snapshot. Extração inicial do backup consistente de 28/09 porque o Anki fechou durante a consulta. Após reabertura, 1.046 notas da amostra + seleção dirigida foram conferidas no perfil vivo User 1: **Text/Extra e modelos iguais**, população igual. Leitura editorial de 72 exemplos (48 de buscas temáticas e 24 aleatórios) e mais 8 exemplos de busca anatômica viva.

Medição do **campo Text completo em inglês, incluindo a resposta**, com HTML e marcadores cloze retirados para contagem. Não é número de palavras visíveis com lacuna oculta, tamanho de imagem ou tempo de resposta. Duas notas com sintaxe não resolvida pelo extrator foram excluídas da estatística de Text. Campos de recursos externos não entram nessa medida.

| Medida | Observação |
|---|---|
| Text: média / mediana | 15,35 / 14 palavras, em 998 notas analisáveis |
| Text: percentis 10 e 90 | 9 e 24 palavras |
| Maior Text da amostra | 72 palavras; não recomendação de tamanho |
| Extra com texto detectado | 774 notas; média 25, mediana 19 palavras |
| Limite da contagem de Extra | Inclui créditos/legendas presentes; não mede exclusivamente explicação didática |
| Notas com negrito no Text | 938 de 1.000 |
| Notas com mais de um índice cloze | 159 de 1.000 |
| Imagem dentro de Text | 22 de 1.000; não estima todas as imagens, muitas estão em Extra/outros campos |

Esses números descrevem **esta amostra deste acervo**. Inglês não define cota de palavras em português. Não medir o sucesso do autoral por cair entre 9 e 24 palavras. A pergunta é se a redação cobra uma recuperação útil sem carregar outras desnecessárias.

## Padrões úteis e o que fazer com eles

| Observação da leitura | Aplicação no NEBLI |
|---|---|
| Contexto e alvo na mesma frase; ocultação geralmente curta | Manter assunto e condição reconhecíveis e ocultar o que realmente precisa ser recuperado |
| Relação causal compacta já ensina com a resposta exposta | Conservar a ligação entre fatos, sem alongar em caso clínico ou ocultar uma explicação inteira |
| Pergunta direta também pode ser didática | Não converter toda boa pergunta em cloze declarativo nem inventar personagem/paciente |
| Extra frequentemente explica um porquê ou contrasta um confundidor | Ajudar uma boa frente pelo verso, conforme Q12B; preservar frente AnKing correta e funcional |
| Clozes diferentes podem separar recuperações na mesma nota | Avaliar cada card; atomicidade é do alvo, não obrigatoriamente uma nota por frase |
| Há notas com vários elementos sob o mesmo c1, inclusive listas | Não copiar a carga só porque vem do AnKing. Q13C favorece perguntas separadas para alvos que mereçam recuperação própria |
| Um texto curto também pode cobrar quatro ou mais respostas independentes | Contagem de palavras não substitui leitura do que precisa ser lembrado |
| Negrito, itálico, sublinhado e hints têm funções locais | Preservar formatação na tradução; em autoria usar destaque econômico, sem código novo de cores |
| Extras às vezes abrem diagnóstico/tratamento extenso | Estudar o estilo não autoriza importar toda a clínica do verso para a aula. Curadoria e tradução são operações distintas |
| Busca por termo amplo encontra outras matérias | “hepatic”/“edema” não provam que um resultado é anatomia/edema do recorte. Reexaminar alvo e ampliar/reformular consultas |

Exemplos rastreáveis na leitura privada: 1506121024151 (relação causal com alvos distintos), 1486608763486 (pergunta focal e verso curto), 1468549202187 (etapa contextualizada), 1493398712106 (vários fatos sob c1 apesar de pouco texto), 1579994847814 (frente focal com Extra muito mais amplo), 1480640304375 (relação anatômica perguntada diretamente). São referências de **forma**, não autorização de inclusão nem conferência clínica desses fatos.

## Escolhas de Davi aplicadas ao estilo

- Manter bom card básico; pôr aplicação no verso salvo ganho excepcional de recuperação própria (Q11C).
- Para autorais novos, alvos independentes que merecem revisão ganham perguntas separadas e autocontidas (Q13C). Não fundir uma sequência inteira para economizar contagem; também não dividir/copiar notas já revisadas como manutenção automática.
- Frente deve fazer sentido quando misturada com outras aulas (Q14A), com contexto mínimo e relevante.
- Negrito econômico e aparência AnKing (Q15A); **não inventar mnemônicos** (Q16C). Recursos existentes podem ser preservados com fonte.
- Qualquer pequena relação clínica compreensível e DIRETAMENTE ligada à aula pode ensinar/relembrar. Sem cota de story tellers; evitar conteúdo novo demais que só amplia uma seleção azul. Se houver pouco ganho, verso ou outra aula resolve melhor.
- Profundidade explicativa não exige frente grande. O tutor futuro deve explicar aprofundadamente e com economia; isso não transforma cada card em uma explicação extensa.

## Evidência e reuso

Artefatos privados em `arquivos-trabalho/nucleo-traducao-2026-09-28/`: `anking-estudo.json`, `anking-estatisticas.json`, `anking-leitura.txt`, `anking-conferencia-viva.json` e `anking-anatomia-adicional.json`. O primeiro contém os textos-fonte preservados e a semente. As coortes iniciais foram obtidas por correspondência parcial de termos em Text no snapshot; seus rótulos de consulta não devem ser copiados literalmente como buscas Anki. O script atual usa curingas e `or` explícito para reproduzir essa intenção via AnkiConnect.

Toda leitura desta rodada foi sem escrita na coleção. Não foram medidas imagens renderizadas, domínio de aprendizagem ou precisão médica integral. A próxima aula usa os achados para seleção/autoria, em conjunto com fontes e feedback; não precisa reexecutar este estudo para cada deck.
