# NEBLI — instruções de entrada
Para E1, cards, Anki, curadoria e arquitetura: ler primeiro `flashcards/projeto/README.md` e seguir sua ordem atual de leitura, incluindo FEEDBACKS.md, BANDEIRAS-E-PROGRESSAO.md e CONTRATO-DE-QUALIDADE.md. O pipeline padrão é **E1 + cards**. E2/E3 são histórico; não executar regras antigas de /resumo.

**Toda sessão:** aplicar o padrão de Davi descrito em README § O que Davi quer e demonstrar sua aplicação na revisão da aula, conforme EXECUCAO-DECK-AULA. Não redefinir cobertura, autoria/story teller, núcleo ou tradução segundo gosto do executor. Recuperar feedbacks e exemplos antes de produzir; dúvidas novas relevantes são calibradas com Davi por exemplos, sem fazê-lo repetir preferências registradas.

Ler também `MEMORY.md` § O projeto que Davi quer, inclusive para pedido por mensagem comum: UC03 é a base calibrada a aperfeiçoar. Todo feedback recebido por Codex/Claude, local ou geral, vai nesta sessão ao registro único conforme FEEDBACKS § Como registrar; reler entradas concorrentes antes de fechar. `CALIBRACAO-DECK-100-PERGUNTAS.md` é a reconferência solicitada, ainda sem respostas na preparação; opções não são decisões. Incorporar respostas por item, sem exigir que Davi julgue quantidade/cobertura médica/verdes.

Para executar: EXECUCAO-DECK-AULA.md, OPERACAO-CODEX-CLAUDE.md, ACERVOS-REFERENCIA.md, `didatica/E1.md` e PUBLICACAO-POR-UC.md no contexto indicado pelo README. Não confundir documentação com automação comprovada.

UC08 desde 29/09: `flashcards/projeto/RECONSTRUCAO-UC08.md` é a fila vigente; sem E1, Claude executa, Codex administra/revisa, pausa a cada par para retorno de Davi. Para o lote antigo/UC03, consultar `flashcards/projeto/FILA-UC03-P2-UC08-P1.md`; a divisão antiga por matéria não rege a reconstrução UC08. Marcar aula antes de começar. Escrita Anki usa `arquivos-trabalho/ANKI-ESCRITA.lock`. Registrar todo feedback no registro único; atualizar regras gerais em seu lugar canônico, não espalhá-las pela fila.

Preservar originais, histórico, edições, flags e suspensões pessoais. Auditoria/planejamento são somente leitura externa, salvo pedido explícito de correção. Não restaurar limpeza manual de artefatos antigos. Não reclassificar toda a coleção: calibrar incrementalmente.

Outras tarefas: CLAUDE.md e MEMORY.md. Preservar alterações locais não relacionadas; regras de etimologia não governam cards médicos. Histórico e versões integrais anteriores em `flashcards/projeto/HISTORICO.md`.
