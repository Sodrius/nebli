# Retomada no Claude

Leia [o handoff canônico](flashcards/projeto/HANDOFF-CLAUDE.md) e siga a entrada de **toda sessão**, incluindo o padrão de Davi no [README](flashcards/projeto/README.md#o-que-davi-quer).

O retrato do projeto e das preferências está no [MEMORY](MEMORY.md#o-projeto-que-davi-quer--recuperar-antes-de-produzir). As [100 perguntas solicitadas por Davi](flashcards/projeto/CALIBRACAO-DECK-100-PERGUNTAS.md) estão preparadas; consultar ali as respostas que forem recebidas, sem presumir alternativas. Pedido por mensagem comum segue a mesma entrada.

A fila e o estado da reconstrução estão em [RECONSTRUCAO-UC08](flashcards/projeto/RECONSTRUCAO-UC08.md). Este arquivo é apenas um encaminhamento; não contém uma segunda cópia das regras ou da próxima atribuição.

A cópia anterior foi preservada no snapshot local de `arquivos-trabalho/alinhamento-transferencia-2026-09-29/antes/`.
