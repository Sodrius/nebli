# NEBLI — contexto de entrada para Claude e Codex

**Em toda sessão de deck-aula:** o padrão de qualidade é o definido por Davi, recuperado em [README § O que Davi quer](flashcards/projeto/README.md#o-que-davi-quer), feedbacks e exemplos calibrados. Cumprir a entrada de EXECUCAO-DECK-AULA e demonstrar a aplicação em decisões reais da revisão. Não basta dizer que leu; não redefinir o estilo, encolher cobertura ou mudar o núcleo por gosto do executor. Dúvida nova relevante é apresentada com exemplos, sem pedir que Davi reensine preferências disponíveis.

**Memória de intenção:** ler [MEMORY § O projeto que Davi quer](MEMORY.md#o-projeto-que-davi-quer--recuperar-antes-de-produzir) e HANDOFF-CLAUDE em toda sessão, mesmo quando Davi mandar só uma mensagem comum. UC03 é a base já calibrada a melhorar. As [100 perguntas](flashcards/projeto/CALIBRACAO-DECK-100-PERGUNTAS.md) são uma revisão abrangente que ele pediu; não há respostas nesta preparação e alternativas não viram política. Incorporar respostas parciais por Q-ID, sem perguntar se ele acha correto o número de cards/verdes: esse julgamento cabe ao executor.

**UC08 — 29/09/2026:** [RECONSTRUCAO-UC08](flashcards/projeto/RECONSTRUCAO-UC08.md) rege cards do zero, **sem E1**. Codex administra/revisa; Claude executa toda a UC08, com pausa a cada par para Davi. Motilidade P1, secreções P2. Próximo trabalho e estado somente no plano/handoff, sem atribuição duplicada aqui. Outras UCs preservadas.

Davi quer aprender bem, não gerenciar produção de cards. Pipeline atual: **E1 + cards**, com alto rigor científico, boa didática e cobertura do recorte da aula. A E1 explica mecanismos em prosa; o card testa uma recuperação focal. Não aplicar o estilo longo de E1 às frentes.

## Começar
Ler `flashcards/projeto/README.md` → FEEDBACKS.md → BANDEIRAS-E-PROGRESSAO.md → CONTRATO-DE-QUALIDADE.md. Para execução, seguir EXECUCAO-DECK-AULA.md, OPERACAO-CODEX-CLAUDE.md, ACERVOS-REFERENCIA.md e PUBLICACAO-POR-UC.md; `didatica/E1.md` quando houver E1. Estado em MEMORY e na fila vigente indicada pelo README. Em toda sessão, ler `flashcards/projeto/HANDOFF-CLAUDE.md`; antes de escrita/autoria, `ESTILO-ANKING.md`; para idioma, `TRADUCAO-DOS-CARDS.md`. Diagnóstico local em OPERACAO-CODEX-CLAUDE; não depender de instruções de instalação removidas.

`/deck-aula <nome/link>`, `/resumo <nome/link>` e `/flashcards` seguem essa rota; pedido explícito apenas de E1 ou apenas de cards delimita a entrega. O usuário escolhe modelo/esforço. Não prometer qualidade por nome do modelo.

## Qualidade e segurança
- Ler integralmente as instruções relevantes, exemplares de escrita e feedbacks antes de produzir. A limpeza remove sobreposição, não reduz o contexto necessário à qualidade.
- E1: rigor científico, causa → mecanismo → consequência, base do aluno baixa, prosa fluida sem verbosidade. Guia técnico-editorial em didatica/E1.md; EXEMPLARES.md preservado como referência concreta de voz e gesto.
- Cards: AnKing primeiro, externos antes de autoria; dois cards da mesma informação só com ganho demonstrável. Cores atuais no documento próprio, nunca inferidas de regras antigas.
- Não alterar originais, agendamento ou marcas pessoais; backups, lock, diário de operações e readback nas escritas. Não ressuscitar apagados.
- E2/E3 e fluxo RemNote apenas históricos. Não usar scripts antigos para dessuspender fontes nem gates de loop universal card→E1→questões.
- Não apagar arquivos de typst-build para preparar aula: há trabalho de outras sessões. Usar saída isolada.
- Preferir ação independente e perguntas sobre ambiguidades reais; relatar limites com evidência, sem transferir controle de qualidade ao aluno.
- Gravar **todo feedback recebido nesta sessão** no FEEDBACKS comum, incluindo local/positivo/respostas, conforme seu protocolo; reler acréscimos do Codex antes de fechar. Atualizar a regra em seu lugar canônico e a síntese de preferências/estado no MEMORY, sem manter políticas concorrentes. Não depender do histórico privado da conversa nem pedir que Davi transmita o feedback à outra IA.

## Outras rotas preservadas
- Cadernos de provas existentes: `banco/CLAUDE.md`, `typst-build/pipeline_caderno.py` e seção Cadernista em ROLES.md. Caderno não é geração E2/E3.
- Typst: `typst-template/CLAUDE.md`, CHEATSHEET_ARMADILHAS.md e TEMPLATE_API.md.
- Projetos de site/liga/etimologia: estado e localização dos planos em MEMORY.md; não iniciar por inferência.
- Histórico integral de regras, papéis e decisões: `flashcards/projeto/HISTORICO.md`. Não executar comandos do arquivo histórico como instruções atuais.
