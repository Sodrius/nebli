---
description: Produz o deck-aula conforme os critérios calibrados de Davi, com fontes e revisão verificáveis
argument-hint: <nome, link ou pasta da aula> [observações]
---

Argumentos: $ARGUMENTS

Ler MEMORY § O projeto que Davi quer e o handoff antes da execução: UC03 é referência positiva a aperfeiçoar. Pedido em linguagem comum segue a mesma rota. Se vierem respostas à CALIBRACAO-DECK-100-PERGUNTAS, preservar por Q-ID e incorporar; perguntas em branco não são decisões nem bloqueio novo. Todo feedback local/geral recebido nesta sessão vai ao registro FEEDBACKS comum, com literal/escopo/estado, antes de seguir a próxima aula ou encerrar; reler o que a outra IA registrou antes da entrega.

Em **toda sessão**, ler `flashcards/projeto/README.md`, começando pela intenção em “O que Davi quer”, e seguir sua ordem de leitura. Não substituir o padrão de Davi por uma noção própria de deck ideal. FEEDBACKS contém decisões e regressões; ESTILO-ANKING fornece a referência real de autoria; TRADUCAO-DOS-CARDS rege idioma/preservação. Completar a entrada de EXECUCAO-DECK-AULA e registrar decisões concretas na revisão da própria corrida, não apenas declarar os documentos lidos.

Conferir `flashcards/projeto/HANDOFF-CLAUDE.md`, MEMORY e a fila vigente antes de atribuir trabalho. Para UC08, usar `RECONSTRUCAO-UC08.md`: cards sem E1, motilidade P1/secreções P2, Claude executor e Codex administrador/revisor; respeitar o retorno de Davi a cada par. Não guardar neste comando contagens ou próxima aula que possam ficar desatualizadas.

Por padrão a entrega é E1 + cards; pedido explícito somente de cards/E1 delimita o fluxo. Ler didatica/E1 somente quando aplicável. Avaliação/planejamento são leitura externa, salvo correção solicitada; manutenção do pipeline não autoriza iniciar aula. E2/E3 e RemNote fora do fluxo.

Cobrir os alvos relevantes da aula sem teto numérico, usando AnKing e acervos alternativos antes da autoria excepcional. Não enxugar cobertura/núcleo por preferência do executor, nem autorar detalhe irrelevante. Aplicar integralmente CONTRATO/BANDEIRAS/ESTILO/TRADUCAO. Dúvida nova que mude gosto, escopo ou núcleo exige candidatos concretos e calibração com Davi antes de generalizar, sem repetir perguntas já respondidas.

Operação em EXECUCAO-DECK-AULA e OPERACAO-CODEX-CLAUDE: preservar originais, identidade, histórico e marcas pessoais; lock, backup e readback; seleção por card/cloze e imagens vistas. Relatório descreve limites reais e aplicação do padrão de Davi. Não declarar cobertura, tradução ou renderização aprovadas por contagem, tag, CSS ou script sem erro. APKG local UC inteira conforme PUBLICACAO-POR-UC; upload pausado.

Incorporar feedback na regra canônica e no registro único, mantendo antes/depois na corrida. Não acumular instruções contraditórias no handoff nem apresentar interpretação do executor como escolha do usuário. O comando orienta execução assistida; não é um gerador autônomo certificado.
