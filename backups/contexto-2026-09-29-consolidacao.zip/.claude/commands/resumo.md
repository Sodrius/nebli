---
description: Produz E1 de alta qualidade e cards NEBLI no pipeline vigente
argument-hint: <nome, link ou pasta da aula> [observações]
---

Argumentos: $ARGUMENTS

Execute a entrada de `.claude/commands/deck-aula.md`, inclusive a aplicação do padrão de Davi em toda sessão. A rota normal é **E1 + cards**, salvo pedido explícito de apenas um deles. Seguir README/FEEDBACKS/BANDEIRAS/CONTRATO; ler didatica/E1 somente se E1 fizer parte da entrega. Estado e exceções da UC08 vêm do handoff/fila vigentes.

Não executar E2/E3, RemNote, loop obrigatório card→E1→questões ou scripts de dessuspensão de originais. Não apagar o workspace compartilhado. Preservar fontes, identidade/histórico e marcas pessoais. Executar runbook atual, com revisão científica e visual; relatório sucinto e estados honestos. APKG local por UC; upload pausado.
